<main class="main">
    <div class="page-header breadcrumb-wrap">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?= base_url('user/dashboard') ?>" rel="nofollow"><i class="fas fa-home mr-10"></i>Home</a>
                <span></span> Shop
                <span></span> Checkout
            </div>
        </div>
    </div>
    <div class="container mb-80 mt-50">
        <form action="<?= site_url('user/dashboard/checkout_proccess') ?>" method="post">
            <div class="row">
                <div class="col-lg-7">
                    <div class="row">
                        <h4 class="mb-30">Billing Details</h4>

                        <div class="row">
                            <div class="form-group col-lg-12">
                                <label for="">Nama </label>
                                <input type="hidden" name="status" id="status" value="0">
                                <input type="hidden" name="id_user" id="id_user" value="<?php echo $this->session->userdata('id_user') ?>">
                                <input type="hidden" id="order_id" name="order_id" value="<?= mt_rand(0000000, 1111111) ?>" maxlength="8" autocomplete="off" required>
                                <input type="text" required="" name="name" value="<?php echo $this->session->userdata('nama_pengguna') ?>" readonly>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-lg-12">
                                <label for="">Alamat Tujuan</label>
                                <textarea rows="5" name="alamat" placeholder="Enter your address"></textarea>
                            </div>
                        </div>
                        <div class="row shipping_calculator">
                            <div class="form-group col-lg-12">
                                <label for="">Provinsi</label>
                                <select class="form-control" name="id_provinsi" id="id_provinsi">
                                    <option hidden>Pilih Provinsi</option>
                                    <?php foreach ($prov as $row) : ?>
                                        <option value="<?= $row->id_provinsi ?>"><?= $row->provinsi ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-lg-12">
                                <label for="">Kabupaten</label>
                                <select class="form-control" name="id_kabupaten" id="id_kabupaten">

                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-lg-12">
                                <label for="">Kecamatan</label>
                                <select class="form-control" name="id_kecamatan" id="id_kecamatan">
                                    <option hidden>Silahkan pilih</option>
                                    <?php foreach ($prov as $row) : ?>
                                        <option value="<?= $row->id_provinsi ?>"><?= $row->provinsi ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-lg-12">
                                <label for="">Kode Pos</label>
                                <input required="" type="text" name="kode_pos" placeholder="Postal Code">
                            </div>
                        </div>
                        <div class="form-group mb-30">
                            <label for="">Keterangan Tambahan</label>
                            <textarea rows="5" name="information" placeholder="Additional information"></textarea>
                        </div>

                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="border p-20 cart-totals mb-50">
                        <div class="d-flex align-items-end justify-content-between mb-20">
                            <h4>Your Order</h4>
                            <h6 class="text-muted">Subtotal</h6>
                        </div>
                        <div class="divider-2 mb-30"></div>
                        <div class="table-responsive order_table checkout">
                            <table class="table no-border mb-5">
                                <tbody>
                                    <?php $no = 1;
                                    foreach ($this->cart->contents() as $items) : ?>
                                        <tr>
                                            <td class="image product-thumbnail"><img src="<?= base_url() . '/uploads/' . $items['options']['gambar']; ?>" alt="#"></td>
                                            <td>
                                                <h6 class="w-160 mb-5"><a href="product-category-list.html" class="text-heading"><?= $items['name']; ?></a></h6>
                                                <div class="product-rating-info">
                                                    <span class="font-small ml-5 text-muted"> x <?= number_format($items['qty'], 0, ',', '.') ?></span>
                                                </div>
                                            </td>
                                            <td>
                                                <small class="text-danger">IDR <?= number_format($items['subtotal'], 0, ',', '.') ?></small>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                            </table>
                        </div>
                    </div>
                    <div class="payment ml-30">
                        <h4 class="mb-30">Payment</h4>
                        <div class="payment_option">
                            <div class="custome-radio">
                                <input class="form-check-input" required="" type="radio" name="payment_method" value="Direct Bank Transfer" id="exampleRadios3" checked="">
                                <label class="form-check-label" for="exampleRadios3" data-bs-toggle="collapse" data-bs-target="#bankTranfer">Direct Bank Transfer</label>
                            </div>
                        </div>
                        <hr>
                        <p>Informasi Pembayaran :</p>
                        <ol type="1">
                            <li><img class="mt-2" src="<?= site_url('assets') ?>/bca.png" width="60"><span style="float: right;"><b>6176171717 / Shopping</b></span></li>
                            <li><img class="mt-2" src="<?= site_url('assets') ?>/dana.png" width="70"><span style="float: right;"><b>08125656514</b></span></li>
                            <li><img class="mt-2" src="<?= site_url('assets') ?>/ovo.png" width="70"><span style="float: right;"><b>08125656514</b></span></li>
                        </ol>
                        <button type="submit" class="btn btn-fill-out btn-block mt-30">Place an Order<i class="fi-rs-sign-out ml-15"></i></button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</main>

<script>
    $(document).ready(function() {
        $("#id_kabupaten").hide();
        $("#id_kecamatan").hide();

        loadkabupaten();
        loadkecamatan();

    });

    function loadkabupaten() {

        $("#id_provinsi").change(function() {
            var getprovinsi = $("#id_provinsi").val();

            $.ajax({
                type: "POST",
                dataType: "JSON",
                url: "<?= base_url(); ?>user/dashboard/getdatakabupaten",
                data: {
                    provinsi: getprovinsi
                },
                success: function(data) {
                    console.log(data);

                    var html = "";
                    var i;
                    for (i = 0; i < data.length; i++) {

                        html += '<option value="' + data[i].id_kabupaten + '">' + data[i].kabupaten + '</option>';

                    }

                    $("#id_kabupaten").html(html)
                    $("#id_kabupaten").show();

                }
            });

        });
    }

    function loadkecamatan() {

        $("#id_kabupaten").change(function() {
            var getkabupaten = $("#id_kabupaten").val();

            $.ajax({
                type: "POST",
                dataType: "JSON",
                url: "<?= base_url(); ?>user/dashboard/getdatakecamatan",
                data: {
                    kabupaten: getkabupaten
                },
                success: function(data) {
                    console.log(data);

                    var html = "";
                    var i;
                    for (i = 0; i < data.length; i++) {

                        html += '<option value="' + data[i].id_kecamatan + '">' + data[i].kecamatan + '</option>';

                    }

                    $("#id_kecamatan").html(html)
                    $("#id_kecamatan").show();

                }
            });

        });
    }
</script>