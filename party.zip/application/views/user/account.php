<main class="main pages">
    <div class="page-header breadcrumb-wrap">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?= base_url('user/dashboard') ?>" rel="nofollow"><i class="fas fa-home mr-10"></i> Home</a>
                <span></span> Profile
            </div>
        </div>
    </div>
    <div class="page-content"> 
        <div class="container">
            <div class="row">
                <div class="col-lg-12 m-auto">
                    <div class="card mb-30">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-lg-12">
                                    <div class="d-flex align-items-center">
                                        <div class="account-profile-img">
                                            <img src="<?= base_url('assets') ?>/img/profile-img.jpg" alt="Image">
                                        </div>
                                        <div class="account-details">
                                            <p>Hello,</p> 
                                            <h4><?php echo $this->session->userdata('nama_pengguna') ?></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="dashboard-menu">
                                <ul class="nav flex-column" id="accordionExample">
                                    <li class="nav-item" id="dashboard-one">
                                        <a class="nav-link active" href="<?= base_url('user/dashboard/account') ?>"><i class="fi-rs-user mr-10"></i>Account Information</a>

                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= base_url('user/dashboard/order') ?>"><i class="fi-rs-shopping-cart mr-10"></i>My Orders</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= base_url('auth/logout') ?>"><i class="fi-rs-sign-out mr-10"></i>Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="account dashboard-content">
                                <div class="card">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h3 class="card-title">Personal Information</h3>
                                        <div class="account-edit">
                                            <a aria-label="editmodal" class="edit-modal-btn" data-bs-toggle="modal" data-bs-target="#editmodal">Edit</a> <span>|</span>
                                            <a aria-label="passwordmodal" class="edit-modal-btn" data-bs-toggle="modal" data-bs-target="#passwordmodal">Change Password</a>
                                        </div>
                                    </div>
                                    <div class="card-body profile-body">
                                        <p><span>Name :</span> <?php echo $this->session->userdata('nama_pengguna') ?></p>
                                        <p><span>Email :</span> <?php echo $this->session->userdata('email') ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Edit Modal -->
<div class="modal fade custom-modal edit-modal" id="editmodal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Your Personal Details</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="feather-x-circle"></i>
                </button>
            </div>
            <div class="modal-body">
                <form action="#" method="post">
                    <div class="input-style mb-15">
                        <input type="text" class="form-control" placeholder="First Name">
                    </div>
                    <div class="input-style mb-15">
                        <input type="text" class="form-control" placeholder="Last Name">
                    </div>
                    <div class="input-style mb-20">
                        <input type="email" class="form-control" placeholder="E-Mail">
                    </div>
                    <div class="input-style d-flex align-items-center justify-content-between mb-5">
                        <button class="btn update-btn" type="submit">Update</button>
                        <button class="btn back-btn" type="submit">Back</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Edit Modal -->

<!-- Password Modal -->
<div class="modal fade custom-modal edit-modal" id="passwordmodal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Change password</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="feather-x-circle"></i>
                </button>
            </div>
            <div class="modal-body">
                <form action="#" method="post">
                    <div class="input-style mb-15">
                        <input type="password" class="form-control" placeholder="Password">
                    </div>
                    <div class="input-style mb-20">
                        <input type="password" class="form-control" placeholder="Confirm Password">
                    </div>
                    <div class="input-style d-flex align-items-center justify-content-between mb-5">
                        <button class="btn update-btn" type="submit">Change</button>
                        <button class="btn back-btn" type="submit">Back</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Password Modal -->