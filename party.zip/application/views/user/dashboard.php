<!-- Main -->
<main class="main">
    <section class="banner-section position-relative">
        <div class="container">
            <div class="banner-slider">
                <div class="banner-slider-one pagination-square align-pagination-square">
                    <div class="banner-slider-single banner-animation-col">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-lg-6">
                                <div class="banner-content">
                                    <h1 class="banner-title mb-40">
                                        Tahun Baru <span>Sale</span> 
                                    </h1>
                                    <p>Kamu Ingin Tampil Good Looking di awal Tahun Baru ini?</p>
                                    <a href="product-category-grid.html" class="shop-now">Shop Now</a>
                                    <span class="border-line"></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6">
                                <div class="single-banner-slider" style="background-image: url(<?= base_url('assets') ?>/BANNER2.JPG)"></div>
                            </div>
                        </div>
                    </div>
                    <div class="banner-slider-single banner-animation-col">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-lg-6">
                                <div class="banner-content">
                                    <h1 class="banner-title mb-40">
                                        <span>DISC 50%</span>
                                    </h1>
                                    <p>Bagi Anda Yang Kaum MISSQUIN ini adalah platform yang cocok bagi anda.</p>
                                    <a href="product-category-grid.html" class="shop-now">Shop Now</a>
                                    <span class="border-line"></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6">
                                <div class="single-banner-slider" style="background-image: url(<?= base_url('assets') ?>/BANNER1.JPG)"></div>
                            </div>
                        </div>
                    </div>
                    <div class="banner-slider-single banner-animation-col">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-lg-6">
                                <div class="banner-content">
                                    <h1 class="banner-title mb-40">
                                         ADA KUALITAS <span>ADA HARGA</span>
                                    </h1>
                                    <p>AYOOO Kaum Mendang-Mending Merapattt.</p>
                                    <a href="product-category-grid.html" class="shop-now">Shop Now</a>
                                    <span class="border-line"></span>
                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6">
                                <div class="single-banner-slider" style="background-image: url(<?= base_url('assets') ?>/BANNER3.JPG)"></div>
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End hero slider-->

    <!-- Feature -->
    <section class="featured section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-4 d-flex">
                    <div class="banner-box d-flex flex-fill align-items-center wow animate__animated animate__fadeInUp" data-wow-delay="0">
                        <div class="banner-icon">
                            <i class="feather-headphones"></i>
                        </div>
                        <div class="banner-text">
                            <h3>Customer care support</h3>
                            <p>Get Help When You Need</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 d-flex">
                    <div class="banner-box d-flex align-items-center flex-fill wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                        <div class="banner-icon">
                            <i class="feather-shield"></i>
                        </div>
                        <div class="banner-text">
                            <h3>Secure Payment</h3>
                            <p>Safe & Fast</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 d-flex">
                    <div class="banner-box d-flex align-items-center flex-fill wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
                        <div class="banner-icon">
                            <i class="feather-truck"></i>
                        </div>
                        <div class="banner-text">
                            <h3>Free Shipping</h3>
                            <p>On all orders</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Feature -->

    <!-- Top Products -->
    <section class="product-tab-section product-section">
        <div class="container">
            <div class="section-title wow animate__animated animate__fadeIn">
                <h3>PRODUCTS LIST</h3>
            </div>
            <!--End nav-tabs-->
            <div class="row product-grid">

                <!-- Product box -->
                <?php foreach ($product as $row) : ?>
                    <div class="col-lg-3 col-md-4 col-12 col-sm-6">
                        <div class="product-card mb-30">
                            <div class="product-img-col">
                                <div class="product-img product-img-zoom">
                                    <a href="view-product.html">
                                        <img src="<?= base_url() . '/uploads/' . $row->gambar ?>" alt="">
                                    </a>
                                </div>
                                <div class="product-badge">
                                    <span class="best">Best</span>
                                </div>
                            </div>
                            <div class="product-content">
                                <h2><a href="view-product.html"><?= $row->nama_brg ?></a></h2>
                                <div class="product-card-bottom mt-0">
                                    <div class="product-price">
                                        <span>IDR <?= number_format($row->harga, 0, ',', '.') ?></span>
                                    </div>
                                </div>
                                <span class="old-price">Sisa : <?= $row->stok?></span>
                                <div class="product-card-bottom">
                                    <div>
                                        <a href="<?= site_url('user/dashboard/cart/' . $row->id_brg) ?>" class="btn btn-sm btn-light"><i class="fi-rs-shopping-cart"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                <!-- /Product box -->

            </div>
            <!-- /Product Tab -->

        </div>
    </section>
    <!-- /Top Products -->

</main>
<!-- /Main -->

<!-- Footer -->
<footer class="footer">
    <section class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="footer-about font-md mb-md-3 mb-lg-3 mb-xl-0 wow animate__animated animate__fadeInUp" data-wow-delay="0">
                        <div class="logo mb-30">
                            <a href="index.html" class="mb-15"><img src="<?= base_url('assets') ?>/img/logo.png" alt="logo" /></a>
                            <p>NOOKX adalah platform E-Commerce yang bergerak dibidang Fashion Pria maupun Wanita dengan kualitas yang sudah terjamin.</p>
                            
                        </div>
                    </div>
                </div>
                <div class="footer-widget col wow animate__animated animate__fadeInUp" data-wow-delay=".1s">
                    <h4 class="footer-title">Contact Info</h4>
                    <ul class="contact-info">
                        <li>
                            <p><i class="fas fa-phone-alt"></i> +62 1234567890</p>
                        </li>
                        <li>
                            <p><i class="fas fa-envelope"></i> example@gmail.com</p>
                        </li>
                        <li>
                            <p><i class="fas fa-map-marker-alt"></i> Bali</p>
                        </li>
                    </ul>
                    <ul class="footer-social-icon">
                        <li><a href="#" target="_blank"><i class="fab fa-facebook"></i></a></li>
                        <li><a href="#" target="_blank"><i class="fab fa-linkedin"></i></a></li>
                        <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                    </ul>
                </div>
                <div class="footer-widget col wow animate__animated animate__fadeInUp" data-wow-delay=".2s">
                    <h4 class="footer-title">Usefull Links</h4>
                    <ul class="footer-list mb-sm-5 mb-md-0">
                        <li><a href="#">Product Recall</a></li>
                        <li><a href="#">Gift Vouchers</a></li>
                        <li><a href="#">Returns & Exchange</a></li>
                        <li><a href="#">Shipping Options</a></li>
                        <li><a href="#">Help & FAQs</a></li>
                    </ul>
                </div>
                <div class="footer-widget col wow animate__animated animate__fadeInUp" data-wow-delay=".3s">
                    <h4 class="footer-title">Quick Links</h4>
                    <ul class="footer-list mb-sm-5 mb-md-0">
                        <li><a href="about-us.html">About Us </a></li>
                        <li><a href="product-category-grid.html">Shop Products</a></li>
                        <li><a href="cart.html">My Cart</a></li>
                        <li><a href="checkout.html">Checkout</a></li>
                        <li><a href="contact-us.html">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <div class="footer-bottom wow animate__animated animate__fadeInUp" data-wow-delay="0">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-5">
                    <p class="font-sm mb-0">Copyright © 2022 NOOKX All rights reserved.</p>
                </div>
                <div class="col-lg-6 col-md-7">
                    <ul class="footer-list mb-sm-5 mb-md-0">
                        <li><a href="#">My Orders</a></li>
                        <li><a href="#">Help</a></li>
                        <li><a href="#">Site Map</a></li>
                        <li><a href="about-us.html">About</a></li>
                        <li><a href="contact-us.html">Contact</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- /Footer -->

<!-- Preloader -->
<div id="loader-wrapper">
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="loaderPill">
            <div class="loaderPill-anim">
                <div class="loaderPill-anim-bounce">
                    <div class="loaderPill-anim-flop">
                        <div class="loaderPill-pill"></div>
                    </div>
                </div>
            </div>
            <div class="loaderPill-floor">
                <div class="loaderPill-floor-shadow"></div>
            </div>
        </div>
    </div>
</div>
<!-- /Preloader -->

<!-- Quick view -->
<div class="modal fade custom-modal" id="quickViewModal" tabindex="-1" aria-labelledby="quickViewModal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <button type="button" class="btn-close quick-close" data-bs-dismiss="modal" aria-label="Close">
                <i class="feather-x-circle"></i>
            </button>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6 col-sm-12 col-xs-12 mb-md-0 mb-sm-5">
                        <div class="detail-gallery">
                            <!-- MAIN SLIDES -->
                            <div class="position-relative">
                                <div class="product-image-slider">
                                    <figure class="border-radius-10">
                                        <img src="<?= base_url('assets') ?>/img/shop/product-big-1.jpg" alt="product image">
                                    </figure>
                                    <figure class="border-radius-10">
                                        <img src="<?= base_url('assets') ?>/img/shop/product-big-2.jpg" alt="product image">
                                    </figure>
                                    <figure class="border-radius-10">
                                        <img src="<?= base_url('assets') ?>/img/shop/product-big-1.jpg" alt="product image">
                                    </figure>
                                    <figure class="border-radius-10">
                                        <img src="<?= base_url('assets') ?>/img/shop/product-big-2.jpg" alt="product image">
                                    </figure>
                                    <figure class="border-radius-10">
                                        <img src="<?= base_url('assets') ?>/img/shop/product-big-1.jpg" alt="product image">
                                    </figure>
                                    <figure class="border-radius-10">
                                        <img src="<?= base_url('assets') ?>/img/shop/product-big-2.jpg" alt="product image">
                                    </figure>
                                    <figure class="border-radius-10">
                                        <img src="<?= base_url('assets') ?>/img/shop/product-big-1.jpg" alt="product image">
                                    </figure>
                                </div>
                                <span class="zoom-icon"><i class="feather-maximize-2"></i></span>
                            </div>
                            <!-- THUMBNAILS -->
                            <div class="slider-nav-thumbnails">
                                <div><img src="<?= base_url('assets') ?>/img/shop/product-big-1.jpg" alt="product image"></div>
                                <div><img src="<?= base_url('assets') ?>/img/shop/product-big-2.jpg" alt="product image"></div>
                                <div><img src="<?= base_url('assets') ?>/img/shop/product-big-1.jpg" alt="product image"></div>
                                <div><img src="<?= base_url('assets') ?>/img/shop/product-big-2.jpg" alt="product image"></div>
                                <div><img src="<?= base_url('assets') ?>/img/shop/product-big-1.jpg" alt="product image"></div>
                                <div><img src="<?= base_url('assets') ?>/img/shop/product-big-2.jpg" alt="product image"></div>
                                <div><img src="<?= base_url('assets') ?>/img/shop/product-big-1.jpg" alt="product image"></div>
                            </div>
                        </div>
                        <!-- End Gallery -->
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">
                        <div class="detail-info">
                            <h5 class="title-detail">EYEBOGLER Regular Fit Men's Cotton Shirt</h5>
                            <div class="clearfix product-price-cover">
                                <div class="product-price primary-color float-left">
                                    <span class="current-price">$ 350.00</span>
                                    <span class="old-price">$ 450.00</span>
                                    <span class="save-price">-72%</span>
                                </div>
                            </div>
                            <ul class="pro-code">
                                <li>Product Code : <span class="text-black">T285HS</span></li>
                                <li>Categories : <span class="text-black">Shirt</span></li>
                            </ul>
                            <div class="rating d-inline-block mb-3">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star-half-alt"></i>
                                <i class="far fa-star"></i>
                                <span class="ml-5"> (3.5)</span>
                            </div>
                            <p class="in-stock text-brand">39 in Stock</p>
                            <div class="detail-extralink">
                                <div class="detail-qty border radius">
                                    <a href="#" class="qty-down"><i class="fi-rs-minus-small"></i></a>
                                    <span class="qty-val">1</span>
                                    <a href="#" class="qty-up"><i class="fi-rs-plus-small"></i></a>
                                </div>
                            </div>
                            <div class="product-extra-link2">
                                <button type="submit" class="button button-add-to-cart me-3"><i class="fi-rs-shopping-cart"></i> ADD TO CART</button>
                                <a aria-label="Add To Wishlist" class="button btn-wishlist" href="wishlist.html"><i class="fi-rs-heart me-1 ms-1"></i></a>
                            </div>
                            <div class="pro-share">
                                <ul>
                                    <li class="me-2"><span>Share :</span></li>
                                    <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                    <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- Detail Info -->

                        <div class="product-info p-0 border-0">
                            <div class="tab-style3">
                                <ul class="nav nav-tabs text-uppercase modal-nav">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="Description-tab" data-bs-toggle="tab" href="#Description">Description</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="Additional-info-tab" data-bs-toggle="tab" href="#Specification">Specification</a>
                                    </li>
                                </ul>
                                <div class="tab-content shop_info_tab entry-main-content">
                                    <div class="tab-pane fade show active" id="Description">
                                        <div class="">
                                            <ul class="pro-desc">
                                                <li>Product Dimensions : 65 x 46 x 1 cm; 240 Grams
                                                <li>Date First Available : 31 October 2020</li>
                                                <li>Manufacturer : Seven Rocks International</li>
                                                <li>ASIN : B08MCZMNDW</li>
                                                <li>Item model number : T285HS</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="Specification">
                                        <ul class="pro-desc">
                                            <li>Item model number : T285HS</li>
                                            <li>Department : Men</li>
                                            <li>Packer : Seven Rocks International</li>
                                            <li>Importer : Seven Rocks International</li>
                                            <li>Item Weight : 240 g</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /Quick view -->