<main class="main pages">
    <div class="page-header breadcrumb-wrap">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?= base_url('user/dashboard') ?>" rel="nofollow"><i class="fas fa-home mr-10"></i> Home</a>
                <span></span> Profile
            </div>
        </div>
    </div>
    <div class="page-content">  
        <div class="container">
            <div class="row">
                <div class="col-lg-12 m-auto">
                    <div class="card mb-30">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-lg-12">
                                    <div class="d-flex align-items-center">
                                        <div class="account-profile-img">
                                            <img src="<?= base_url('assets') ?>/img/profile-img.jpg" alt="Image">
                                        </div>
                                        <div class="account-details">
                                            <p>Hello,</p>
                                            <h4><?php echo $this->session->userdata('nama_pengguna') ?></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="dashboard-menu">
                                <ul class="nav flex-column" id="accordionExample">
                                    <li class="nav-item" id="dashboard-one">
                                        <a class="nav-link active accordion-button collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne"><i class="fi-rs-user mr-10"></i>Account Information</a>
                                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="dashboard-one" data-bs-parent="#accordionExample">
                                            <ul class="dashboard-sub-link">
                                                <li><a href="<?= base_url('user/dashboard/account') ?>">My Profile</a></li>
                                                <li><a href="<?= base_url('user/dashboard/address') ?>" class="active">Manage address</a></li>
                                            </ul>
                                        </div>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="orders.html"><i class="fi-rs-shopping-cart mr-10"></i>My Orders</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="index.html"><i class="fi-rs-sign-out mr-10"></i>Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="account dashboard-content">
                                <div class="card border-0 mb-25">
                                    <div class="card-header card-header-border d-flex align-items-center justify-content-between pt-0">
                                        <h3 class="card-title">Manage Address</h3>
                                        <div class="account-edit">
                                            <a aria-label="addmodal" class="btn modal-btn-address" data-bs-toggle="modal" data-bs-target="#addmodal">+ ADD A NEW ADDRESS</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card border-0 mb-25">
                                    <div class="card-header p-0">
                                        <p class="card-content">Saved Address</p>
                                    </div>
                                </div>
                                <div class="row">
                                    <?php if (empty($address)) { ?>
                                        <img src="<?= base_url('assets') ?>/be/images/gfx/error-404.svg" width="200px" height="300px" alt="">
                                        <div class="text center">
                                            <center>
                                                <h3 class="nk-error-title">Oops! Data Not Found.</h3>
                                                <p class="nk-error-text">You have not entered your address data.</p>
                                        </div>
                                    <?php } else { ?>
                                        <?php foreach ($address as $row) : ?>
                                            <div class="col-lg-4">
                                                <div class="card mb-25">
                                                    <div class="card-body">
                                                        <div class="card-header card-header-border">
                                                            <h4 class="card-sub-title"><?= $row->tempat ?></h4>
                                                        </div>
                                                        <div class="card-details">
                                                            <h4 class="card-details-title"><?= $row->nama_pengguna ?></h4>
                                                            <p><i class="feather-phone"></i> +62 <?= $row->no_hp ?></p>
                                                            <p class="d-flex"><i class="feather-map-pin"></i> <?= $row->alamat ?>, <?= $row->provinsi ?>, <?= $row->kabupaten ?>, <?= $row->kecamatan ?>, <?= $row->kode_pos ?></p>
                                                            <a href="#" aria-label="editmodal" data-bs-toggle="modal" data-bs-target="#editmodal">Edit</a> <span>|</span>
                                                            <a href="#">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Edit Modal -->
<div class="modal fade custom-modal edit-modal" id="editmodal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create Address</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="feather-x-circle"></i>
                </button>
            </div>
            <div class="modal-body">
                <form action="#" method="post">
                    <div class="input-style mb-15">
                        <input type="text" class="form-control" placeholder="Home or Office" value="Home">
                    </div>
                    <div class="input-style mb-15">
                        <input type="text" class="form-control" placeholder="Address 1" value="3556 Beech Street, San Francisco">
                    </div>
                    <div class="input-style mb-15">
                        <input type="text" class="form-control" placeholder="Address 2" value="California, CA">
                    </div>
                    <div class="input-style mb-20">
                        <select class="form-select">
                            <option>USA</option>
                            <option>India</option>
                            <option>Russia</option>
                            <option>London</option>
                        </select>
                    </div>
                    <div class="input-style mb-20">
                        <input type="text" class="form-control" placeholder="Zip Code" value="94108">
                    </div>
                    <div class="input-style mb-20">
                        <input type="text" class="form-control" placeholder="Phone Number" value="5396 5250 1908">
                    </div>
                    <div class="input-style d-flex align-items-center justify-content-between mb-5">
                        <button class="btn update-btn" type="submit">Create</button>
                        <button class="btn back-btn" type="submit">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Edit Modal -->

<!-- Add Modal -->
<div class="modal fade custom-modal edit-modal" id="addmodal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create Address</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="feather-x-circle"></i>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('user/dashboard/insert_address') ?>" method="post">
                    <div class="mb-15">
                        <input type="hidden" name="id_user" value="<?php echo $this->session->userdata('id_user') ?>">
                        <select name="tempat" class="form-control">
                            <option hidden>Pilih Tempat</option>
                            <option value="Home">Home</option>
                            <option value="Office">Office</option>
                        </select>
                    </div>
                    <div class="mb-15">
                        <textarea class="form-control" name="alamat" placeholder="Enter your address"></textarea>
                    </div>
                    <div class="mb-20">
                        <select class="form-control" name="id_provinsi" id="id_provinsi">
                            <option hidden>Pilih Provinsi</option>
                            <?php foreach ($prov as $row) : ?>
                                <option value="<?= $row->id_provinsi ?>"><?= $row->provinsi ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-20">
                        <select class="form-control" name="id_kabupaten" id="id_kabupaten">

                        </select>
                    </div>
                    <div class="mb-20">
                        <select class="form-control" name="id_kecamatan" id="id_kecamatan">
                            <option hidden>Silahkan pilih</option>
                            <?php foreach ($prov as $row) : ?>
                                <option value="<?= $row->id_provinsi ?>"><?= $row->provinsi ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-20">
                        <input type="text" class="form-control" name="kode_pos" placeholder="Zip Code">
                    </div>
                    <div class="mb-20">
                        <input type="text" class="form-control" name="no_hp" placeholder="Phone Number">
                    </div>
                    <div class="d-flex align-items-center justify-content-between mb-5">
                        <button class="btn update-btn" type="submit">Create</button>
                        <button class="btn back-btn" type="submit">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- /Add Modal -->