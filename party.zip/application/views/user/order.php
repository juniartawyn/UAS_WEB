<main class="main pages">
    <div class="page-header breadcrumb-wrap">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?= base_url('user/dashboard') ?>" rel="nofollow"><i class="fas fa-home mr-10"></i> Home</a>
                <span></span> Orders list
            </div>
        </div>
    </div>
    <div class="page-content"> 
        <div class="container">
            <div class="row">
                <div class="col-lg-12 m-auto">
                    <div class="card mb-30">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-lg-12">
                                    <div class="d-flex align-items-center">
                                        <div class="account-profile-img">
                                            <img src="<?= base_url('assets') ?>/img/profile-img.jpg" alt="Image">
                                        </div>
                                        <div class="account-details">
                                            <p>Hello,</p>
                                            <h4><?php echo $this->session->userdata('nama_pengguna') ?></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="dashboard-menu">
                                <ul class="nav flex-column" id="accordionExample">
                                    <li class="nav-item" id="dashboard-one">
                                        <a class="nav-link" href="<?= base_url('user/dashboard/account') ?>"><i class="fi-rs-user mr-10"></i>Account Information</a>

                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link active" href="<?= base_url('user/dashboard/order') ?>"><i class="fi-rs-shopping-cart mr-10"></i>My Orders</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= base_url('auth/logout') ?>"><i class="fi-rs-sign-out mr-10"></i>Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="account dashboard-content">
                                <div class="card border-0 mb-25">
                                    <div class="card-header card-header-border d-flex align-items-center justify-content-between pt-0">
                                        <h3 class="card-title">My Orders</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <?php if (empty($order)) { ?>
                                        <center><img src="<?= site_url('assets') ?>/found.png" width="200"><br>
                                            <b>Oops...Anda belum mempunyai pesanan!</b>
                                        <?php } else { ?>
                                            <?php foreach ($order as $row) : ?>
                                                <div class="col-lg-12">
                                                    <div class="card mb-25">
                                                        <div class="card-header card-header-ordered d-flex align-items-center justify-content-between">
                                                            <h4 class="card-sub-title">Order on <?php echo date('F d, Y', strtotime($row->transaction_time)); ?></h4>
                                                            <?php if ($row->status == "0") { ?>
                                                                <p class="bg-ordered">PENDING</p>
                                                            <?php } else if ($row->status == "1") { ?>
                                                                <p class="bg-paid">PAID</p>
                                                            <?php } ?>
                                                        </div>
                                                        <div class="card-body">
                                                            <div class="card-details pt-0">
                                                                <div class="card-delivery">
                                                                    <p><i class="feather-credit-card"></i> <?= $row->payment_method ?></p>
                                                                    <p><i class="feather-map-pin"></i> <?= $row->alamat ?>, <?= $row->provinsi ?>, <?= $row->kabupaten ?>, Kec. <?= $row->kecamatan ?>, <?= $row->kode_pos ?></p>
                                                                    <?php if (empty($row->gambar)) { ?>
                                                                        <a data-bs-toggle="modal" data-bs-target="#passwordmodal" class="btn">Upload Bukti</a>
                                                                    <?php } else { ?>
                                                                        <a href="<?= site_url('user/dashboard/invoice/' . $row->order_id) ?>" class="btn">Download invoice</a>
                                                                    <?php } ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Password Modal -->
<?php foreach ($order as $row) : ?>
    <div class="modal fade custom-modal edit-modal" id="passwordmodal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Upload Bukti</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                        <i class="feather-x-circle"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= site_url('user/dashboard/upload') ?>" method="post" enctype="multipart/form-data">
                        <div class="input-style mb-15">
                            <input type="hidden" name="order_id" value="<?= $row->order_id ?>">
                            <input type="file" class="form-control" name="gambar" value="<?= $row->gambar ?>">
                        </div>
                        <div class="input-style d-flex align-items-center justify-content-between mb-5">
                            <button class="btn back-btn" data-bs-dismiss="modal" aria-label="Close" type="button">Cancel</button>
                            <button class="btn update-btn" type="submit">Upload</button>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
<!-- /Password Modal -->