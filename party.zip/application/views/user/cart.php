<main class="main">
    <div class="page-header breadcrumb-wrap">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?= base_url('user/dashboard') ?>" rel="nofollow"><i class="fas fa-home mr-10"></i> Home</a>
                <span></span> Cart
            </div>
        </div>
    </div>
    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive shopping-table">
                        <table class="table">
                            <thead>
                                <tr class="table-head"> 
                                    <th>Product</th>
                                    <th>Product Name</th>
                                    <th>Quantity</th>
                                    <th>Product Price</th>
                                    <th>Price</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no = 1;
                                foreach ($this->cart->contents() as $items) : ?>
                                    <tr class="table-head">
                                        <td class="image product-thumbnail">
                                            <a href="#"><img src="<?= base_url() . '/uploads/' . $items['options']['gambar']; ?>" class="img-fluid" alt=""></a>
                                        </td>
                                        <td><a href="#"><?= $items['name']; ?></a></td>
                                        <td><?= number_format($items['qty'], 0, ',', '.') ?> items</td>
                                        <td>IDR <?= number_format($items['price'], 0, ',', '.') ?></td>
                                        <td>IDR <?= number_format($items['subtotal'], 0, ',', '.') ?></td>
                                        <td><a href="<?= site_url('user/dashboard/delete_row/' . $items['rowid']) ?>" class="table-btn-close"><i class="feather-x-circle"></i></a></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="shop-cart">
                    <div class="row">
                        <div class="col-lg-8 col-md-6">
                            <div class="shop-cart-action">
                                <a href="<?= base_url('user/dashboard') ?>" class="btn continue-btn">Continue Shopping</a>
                                <a href="<?= site_url('user/dashboard/clear') ?>" class="btn basket-btn">Empty Basket</a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="card">
                                <div class="card-body">
                                    <div class="shop-cart-info">
                                        <p>Tax <span>-</span></p>
                                        <p>Total <span>IDR <?= number_format($this->cart->total(), 0, ',', '.') ?>,-</span></p>
                                        <a href="<?= base_url('user/dashboard/checkout') ?>" class="btn checkout-btn w-100">Go To Checkout</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>