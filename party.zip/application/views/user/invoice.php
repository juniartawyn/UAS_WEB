<main class="main pages">
    <div class="page-header breadcrumb-wrap">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?= base_url('user/dashboard') ?>" rel="nofollow"><i class="fas fa-home mr-10"></i> Home</a>
                <span></span> Invoice
            </div>
        </div>
    </div>
    <div class="page-content">
        <div class="container">
            <div class="row"> 
                <div class="col-lg-12 m-auto">
                    <div class="card mb-30">
                        <div class="card-body">
                            <div class="row align-items-center">
                                <div class="col-lg-12">
                                    <div class="d-flex align-items-center">
                                        <div class="account-profile-img">
                                            <img src="<?= base_url('assets') ?>/img/profile-img.jpg" alt="Image">
                                        </div>
                                        <div class="account-details">
                                            <p>Hello,</p>
                                            <h4><?php echo $this->session->userdata('nama_pengguna') ?></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <div class="dashboard-menu">
                                <ul class="nav flex-column" id="accordionExample">
                                    <li class="nav-item" id="dashboard-one">
                                        <a class="nav-link" href="<?= base_url('user/dashboard/account') ?>"><i class="fi-rs-user mr-10"></i>Account Information</a>

                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link active" href="<?= base_url('user/dashboard/order') ?>"><i class="fi-rs-shopping-cart mr-10"></i>My Orders</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?= base_url('auth/logout') ?>"><i class="fi-rs-sign-out mr-10"></i>Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="account dashboard-content">
                                <div class="card border-0 mb-30">
                                    <div class="card-header card-header-border d-flex align-items-center justify-content-between pt-0">
                                        <h3 class="card-title">Invoice Preview</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="card mb-0">
                                            <div class="invoice-header pb-0">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="invoice-logo">
                                                            <img src="<?= base_url('assets') ?>/img/logo.png" class="img-fluid" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="invoice-thumb">
                                                            <h4>INVOICE</h4>
                                                            <p>#<?= $invoice->order_id ?></p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card-body pb-0">
                                                <div class="invoice-details">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="invoice-item">
                                                                <h4><?= $invoice->name ?></h4>
                                                                <?php foreach ($order as $val) : ?>
                                                                    <p class="mb-0"><?= $invoice->alamat ?>, <br> <?= $val->provinsi ?>, <?= $val->kabupaten ?><br> Kec. <?= $val->kecamatan ?>, <?= $val->kode_pos ?></p>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="invoice-item invoice-item-right">

                                                                <p>Invoice Date: Dec 20, 2021</p>
                                                                <p class="mb-0">Terms: Payment Due On Receipt</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="invoice-inner-table">
                                                    <div class="table-responsive">
                                                        <table class="table m-0">
                                                            <thead>
                                                                <tr class="table-head-border">
                                                                    <th>#</th>
                                                                    <th>Product Name</th>
                                                                    <th>RATE</th>
                                                                    <th>QTY</th>
                                                                    <th>Amount</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $no = 1;
                                                                $total = 0;
                                                                foreach ($pesanan as $row) :
                                                                    $subtotal = $row->jumlah * $row->harga;
                                                                    $total += $subtotal;
                                                                ?>
                                                                    <tr>
                                                                        <td><?= $no++; ?></td>
                                                                        <td><span><?= $row->nama_brg ?></span></td>
                                                                        <td>IDR <?= number_format($row->harga, 0, ',', '.') ?></td>
                                                                        <td>x <?= number_format($row->jumlah, 0, ',', '.') ?></td>
                                                                        <td>IDR <?= number_format($subtotal, 0, ',', '.') ?></td>
                                                                    </tr>
                                                                <?php endforeach; ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="invoice-other-info">
                                                            <p>Payment Method : <?= $invoice->payment_method ?></p>
                                                            <p>Payment Status : <?php if ($invoice->status == "0") { ?>
                                                                    <span class="text-warning">Ordered</span>
                                                                <?php } else if ($invoice->status == "1") { ?>
                                                                    <span class="text-success">Paid</span>
                                                                <?php } ?>
                                                            </p>
                                                        </div>
                                                        <div class="invoice-other-info pb-20">
                                                            <h4>Authorized person</h4>
                                                            <p>Signature</p>
                                                            <p>(David Peterson)</p>
                                                            <p class="mb-0">Business Owner</p>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="card shop-cart-card">
                                                            <div class="card-body">
                                                                <div class="shop-cart-info">
                                                                    <p>Tax <span>-</span></p>
                                                                    <p>Total <span>$ <?= number_format($total, 0, ',', '.') ?></span></p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>