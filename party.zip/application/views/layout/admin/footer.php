<!-- JavaScript -->
<script src="<?= base_url('assets') ?>/be/assets/js/bundle.js?ver=3.1.1"></script>
<script src="<?= base_url('assets') ?>/be/assets/js/scripts.js?ver=3.1.1"></script>
<script src="<?= base_url('assets') ?>/be/assets/js/charts/chart-ecommerce.js?ver=3.1.1"></script>
<script src="<?= base_url('assets') ?>/be/assets/js/libs/datatable-btns.js?ver=3.1.1"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.33.1/sweetalert2.min.js"></script>
<script>
    // function myFunction() {
    //   // Get the text field
    //   var copyText = document.getElementById("myInput");

    //   // Select the text field
    //   copyText.select();
    //   copyText.setSelectionRange(0, 99999); // For mobile devices

    //   // Copy the text inside the text field
    //   navigator.clipboard.writeText(copyText.value);

    //   // Alert the copied text
    //   swal({

    //     title: "Berhasil!",

    //     text: "Tautan berhasil disalin",

    //     icon: "success",

    //     button: true

    //   });
    // }
    var clipboard = new ClipboardJS('.btn');

    clipboard.on('success', function(e) {
        console.info('Action:', e.action);
        console.info('Text:', e.text);
        console.info('Trigger:', e.trigger);

        // Alert the copied text
        swal({

            title: "Berhasil!",

            text: "Order number berhasil disalin",

            icon: "success",

            button: true

        });
    });

    clipboard.on('error', function(e) {
        console.error('Action:', e.action);
        console.error('Trigger:', e.trigger);
    });
</script>


<?php if (@$_SESSION['sukses']) { ?>
    <script>
        swal("Good job!", "<?php echo $_SESSION['sukses']; ?>", "success");
    </script>
    <!-- jangan lupa untuk menambahkan unset agar sweet alert tidak muncul lagi saat di refresh -->
<?php unset($_SESSION['sukses']);
} ?>


<?php if (@$_SESSION['gagal']) { ?>
    <script>
        swal("Please Wait", "<?php echo $_SESSION['gagal']; ?>", "error");
    </script>
    <!-- jangan lupa untuk menambahkan unset agar sweet alert tidak muncul lagi saat di refresh -->
<?php unset($_SESSION['gagal']);
} ?>


<?php if (@$_SESSION['pending']) { ?>
    <script>
        swal("Please Wait", "<?php echo $_SESSION['pending']; ?>", "warning");
    </script>
    <!-- jangan lupa untuk menambahkan unset agar sweet alert tidak muncul lagi saat di refresh -->
<?php unset($_SESSION['pending']);
} ?>
<!-- END: JS Assets-->
</body>

</html>