<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NOOKX - Platform</title>

    
    <!-- Animate CSS -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/css/animate.min.css">

    <!-- Main CSS -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/css/style.css">
</head>

<body>

    <!-- Header -->
    <header class="header">
        <div class="mobile-view">
            <span>Grand opening, <strong>up to 15%</strong> off all items. Only <strong>3 days</strong> left</span>
        </div>
        <div class="header-top d-none d-lg-block">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-xl-3 col-lg-4">
                        <div class="header-left">
                            <ul>
                                <li>

                                </li>
                                <li>

                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4">
                        <div class="header-details">
                            <div class="header-inner">
                                <div class="header-inner-icon">
                                    <a href="<?= site_url('auth') ?>" class="d-flex align-items-center">
                                        <span><img src="<?= base_url('assets') ?>/img/icons/icon-profile.svg" alt=""></span>
                                        <span class="lable mt-0">My Account</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-middle d-none d-lg-block">
            <div class="container">
                <div class="header-col">
                    <div class="logo header-logo">
                        <a href="index.html"><img src="<?= base_url('assets') ?>/img/logo.png" alt="logo"></a>
                    </div>
                    <div class="header-right">
                        <div class="header-search">
                            <form action="<?= base_url('id/search') ?>" method="post">
                                <input type="text" name="keyword" placeholder="Search for items or categories">
                                <input type="submit" name="form-submit" class="submit-btn">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </header>
    <div class="main-menu-wrapper">
        <div class="mobile-header-inner">
            <div class="mobile-header-top">
                <div class="mobile-header-logo">
                    <a href="index.html"><img src="<?= base_url('assets') ?>/img/logo.png" alt="logo" /></a>
                </div>
                <div class="mobile-menu-close close-col menu-close-position">
                    <button class="close-style">
                        <i class="icon-top"></i>
                        <i class="icon-bottom"></i>
                    </button>
                </div>
            </div>
            <div class="mobile-header-content">
                <div class="mobile-search mobile-search-three mobile-header-border">
                    <form action="product-category-list.html">
                        <input type="text" placeholder="Search for items…" />
                        <button type="submit"><i class="fi-rs-search"></i></button>
                    </form>
                </div>
                <div class="mobile-menu-col mobile-header-border">

                    <!-- Mobile Menu -->
                    <nav>
                        <ul class="main-nav">
                            <li class="mobile-menu-item">
                                <a href="index.html">Home</a>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#">Beauty</a>
                                <ul class="dropdown">
                                    <li><a href="#">Beauty 1</a></li>
                                    <li><a href="#">Beauty 2</a></li>
                                    <li><a href="#">Beauty 3</a></li>
                                    <li><a href="#">Beauty 4</a></li>
                                </ul>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#">Books</a>
                                <ul class="dropdown">
                                    <li><a href="#">Books 1</a></li>
                                    <li><a href="#">Books 2</a></li>
                                    <li><a href="#">Books 3</a></li>
                                    <li><a href="#">Books 4</a></li>
                                </ul>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#">Computers</a>
                                <ul class="dropdown">
                                    <li><a href="#">Computers 1</a></li>
                                    <li><a href="#">Computers 2</a></li>
                                    <li><a href="#">Computers 3</a></li>
                                    <li><a href="#">Computers 4</a></li>
                                </ul>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#">Shop</a>
                                <ul class="dropdown">
                                    <li><a href="cart.html">Shop - Cart</a></li>
                                    <li><a href="address.html">Shop - Address</a></li>
                                    <li><a href="delivery.html">Shop - Delivery</a></li>
                                    <li><a href="checkout.html">Shop - Checkout</a></li>
                                </ul>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#">Blog</a>
                                <ul class="dropdown">
                                    <li><a href="blog-list.html">Blog List</a></li>
                                    <li><a href="blog-grid.html">Blog Grid</a></li>
                                    <li><a href="blog-details.html">Blog Details</a></li>
                                </ul>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#">Mega menu</a>
                                <ul class="dropdown">
                                    <li class="mobile-menu-item">
                                        <a href="#">Women's Fashion</a>
                                        <ul class="dropdown">
                                            <li><a href="product-category-list.html">Dresses</a></li>
                                            <li><a href="product-category-list.html">Blouses & Shirts</a></li>
                                            <li><a href="product-category-list.html">Hoodies & Sweatshirts</a></li>
                                            <li><a href="product-category-list.html">Women's Sets</a></li>
                                        </ul>
                                    </li>
                                    <li class="mobile-menu-item">
                                        <a href="#">Men's Fashion</a>
                                        <ul class="dropdown">
                                            <li><a href="product-category-list.html">Jackets</a></li>
                                            <li><a href="product-category-list.html">Casual Faux Leather</a></li>
                                            <li><a href="product-category-list.html">Genuine Leather</a></li>
                                        </ul>
                                    </li>
                                    <li class="mobile-menu-item">
                                        <a href="#">Technology</a>
                                        <ul class="dropdown">
                                            <li><a href="product-category-list.html">Gaming Laptops</a></li>
                                            <li><a href="product-category-list.html">Ultraslim Laptops</a></li>
                                            <li><a href="product-category-list.html">Tablets</a></li>
                                            <li><a href="product-category-list.html">Laptop Accessories</a></li>
                                            <li><a href="product-category-list.html">Tablet Accessories</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#">Pages</a>
                                <ul class="dropdown">
                                    <li><a href="about-us.html">About Us</a></li>
                                    <li><a href="account.html">My Account</a></li>
                                    <li><a href="login.html">Login</a></li>
                                    <li><a href="register.html">Register</a></li>
                                    <li><a href="contact-us.html">Contact Us</a></li>
                                    <li><a href="privacy-policy.html">Privacy Policy</a></li>
                                    <li><a href="terms-conditions.html">Terms of Service</a></li>
                                </ul>
                            </li>
                            <li class="mobile-menu-item">
                                <a href="#">Language</a>
                                <ul class="dropdown">
                                    <li><a href="#">English</a></li>
                                    <li><a href="#">French</a></li>
                                    <li><a href="#">German</a></li>
                                    <li><a href="#">Spanish</a></li>
                                </ul>
                            </li>
                        </ul>
                    </nav>
                    <!-- /Mobile Menu -->

                </div>
            </div>
        </div>
    </div>
    <!-- /Header -->