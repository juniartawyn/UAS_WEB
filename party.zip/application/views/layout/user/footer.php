<!-- jQuery -->
<script src="<?= base_url('assets') ?>/js/jquery-3.6.0.min.js"></script>

<!-- Bootstrap Core JS -->
<script src="<?= base_url('assets') ?>/js/bootstrap.bundle.min.js"></script>

<!-- Slick JS -->
<script src="<?= base_url('assets') ?>/plugins/slick/slick.js"></script>

<!-- Wow JS -->
<script src="<?= base_url('assets') ?>/js/wow.js"></script>

<!-- Select2 JS -->
<script src="<?= base_url('assets') ?>/plugins/select2/select2.min.js"></script>

<!-- Scrollup JS -->
<script src="<?= base_url('assets') ?>/js/scrollup.js"></script>

<!-- Sidebar JS -->
<script src="<?= base_url('assets') ?>/plugins/theia-sticky-sidebar/jquery.theia.sticky.js"></script>

<!-- Elevatezoom JS -->
<script src="<?= base_url('assets') ?>/js/jquery.elevatezoom.js"></script>

<!-- Scrollbar JS -->
<script src="<?= base_url('assets') ?>/plugins/perfect-scrollbar/perfect-scrollbar.js"></script>

<!-- Waypoints JS -->
<script src="<?= base_url('assets') ?>/js/waypoints.js"></script>

<!-- Shop JS -->
<script src="<?= base_url('assets') ?>/js/shop.js"></script>

<!-- Custom JS -->
<script src="<?= base_url('assets') ?>/js/script.js"></script>



</body>

</html>