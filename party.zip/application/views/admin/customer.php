<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">Customer Lists</h3>
                            <div class="nk-block-des text-soft">
                                <p>You have total <?= number_format($user) ?> customers.</p>
                            </div>
                        </div><!-- .nk-block-head-content -->
                        <div class="nk-block-head-content">
                            <div class="toggle-wrap nk-block-tools-toggle">
                                <a href="#" class="btn btn-icon btn-trigger toggle-expand me-n1" data-target="more-options"><em class="icon ni ni-more-v"></em></a>

                            </div>
                        </div><!-- .nk-block-head-content -->
                    </div><!-- .nk-block-between -->
                </div><!-- .nk-block-head -->
                <div class="nk-block">
                    <div class="nk-tb-list is-separate mb-3">
                        <div class="nk-tb-item nk-tb-head">
                            <div class="nk-tb-col nk-tb-col-check">
                                <div class="custom-control custom-control-sm custom-checkbox notext">
                                    <input type="checkbox" class="custom-control-input" id="uid">
                                    <label class="custom-control-label" for="uid"></label>
                                </div>
                            </div>
                            <div class="nk-tb-col"><span class="sub-text">User</span></div>
                            <div class="nk-tb-col tb-col-md"><span class="sub-text">Phone</span></div>
                            <div class="nk-tb-col tb-col-lg"><span class="sub-text">Role</span></div>
                            <div class="nk-tb-col tb-col-md"><span class="sub-text">Status</span></div>

                        </div><!-- .nk-tb-item -->
                        <?php foreach ($customer as $row) : ?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col nk-tb-col-check">
                                    <div class="custom-control custom-control-sm custom-checkbox notext">
                                        <input type="checkbox" class="custom-control-input" id="uid1">
                                        <label class="custom-control-label" for="uid1"></label>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
                                    <a href="html/ecommerce/customer-details.html">
                                        <div class="user-card">
                                            <div class="user-avatar bg-primary">
                                                <span>AB</span>
                                            </div>
                                            <div class="user-info">
                                                <span class="tb-lead"><?= $row->nama_pengguna ?> <span class="dot dot-success d-md-none ms-1"></span></span>
                                                <span><?= $row->email ?></span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <span>+62 <?= $row->no_hp ?></span>
                                </div>
                                <div class="nk-tb-col tb-col-lg">
                                    <span>Customer</span>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <span class="tb-status text-success">Active</span>
                                </div>
                            </div><!-- .nk-tb-item -->
                        <?php endforeach; ?>
                    </div><!-- .nk-tb-list -->
                </div><!-- .nk-block -->
            </div>
        </div>
    </div>
</div>