<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">
                    <div class="nk-block-head nk-block-head-lg wide-sm">
                        <div class="nk-block-head-content">
                            <div class="nk-block-head-sub"><a class="back-to" href="html/components.html"><em class="icon ni ni-arrow-left"></em><span>Components</span></a></div>

                        </div>
                    </div><!-- .nk-block-head -->
                    <div class="nk-block nk-block-lg">
                        <div class="nk-block-head">
                            <div class="nk-block-head-content">
                                <h4 class="title nk-block-title">Filter Pencarian</h4>
                                
                            </div>
                        </div>
                        <div class="card card-bordered card-preview">
                            <div class="card-inner">
                                <div class="preview-block">
                                    <form method="post" action="<?php echo base_url('admin/report/') ?>">
                                        <div class="row gy-4">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="form-label" for="default-01">Mulai Tanggal</label>
                                                    <div class="form-control-wrap">
                                                        <input type="date" class="form-control" id="default-01" placeholder="Input placeholder">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="form-label" for="default-01">Sampai Tanggal</label>
                                                    <div class="form-control-wrap">
                                                        <input type="date" class="form-control" id="default-01" placeholder="Input placeholder">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <hr class="preview-hr">
                                        <button type="submit" class="btn btn-sm btn-primary"><em class="icon ni ni-filter"></em>&nbsp; Filter</button>
                                        <a href="<?= base_url('admin/report/pdf_view') ?>" target="_blank" class="btn btn-sm btn-danger"><em class="icon ni ni-file-pdf"></em>&nbsp; Download PDF</a>

                                    </form>
                                </div>
                            </div>
                        </div><!-- .card-preview -->

                    </div><!-- .nk-block -->

                    <br>

                    <div class="nk-block nk-block-lg">
                        <div class="card card-bordered card-preview">
                            <div class="card-inner">
                                <div class="preview-block">
                                    <?php if (empty($data)) { ?>
                                        <center><img src="<?= site_url('assets') ?>/found.png" width="200"><br>
                                            <b>Oops...Data yang anda cari tidak dapat ditemukan!</b>
                                        <?php } else { ?>
                                            <table class="table table-orders">
                                                <thead class="tb-odr-head">
                                                    <tr class="tb-odr-item">
                                                        <th class="tb-odr-info">
                                                            <span class="tb-odr-id">Customer</span>
                                                            <span class="tb-odr-date d-none d-md-inline-block">Rent Time Period</span>
                                                        </th>
                                                        <th class="tb-odr-amount">
                                                            <span class="tb-odr-status d-none d-md-inline-block">Status</span>
                                                        </th>
                                                        <th class="tb-odr-action">&nbsp;</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="tb-odr-body">
                                                    <?php foreach ($data as $row) : ?>
                                                        <tr class="tb-odr-item">
                                                            <td class="tb-odr-info">
                                                                <span class="tb-odr-id"><a href="#"><?= $row->name ?></a></span>
                                                                <span class="tb-odr-date"><?php echo $row->transaction_time ?></span>
                                                            </td>
                                                            <td class="tb-odr-amount">
                                                                <?php if ($row->status == "0") { ?>
                                                                    <span class="tb-odr-status">
                                                                        <span class="badge badge-dot bg-warning">Pending</span>
                                                                    </span>
                                                                <?php } else if ($row->status == "1") { ?>
                                                                    <span class="tb-odr-status">
                                                                        <span class="badge badge-dot bg-success">Payment Succesfully</span>
                                                                    </span>
                                                                <?php } ?>
                                                            </td>
                                                            <td class="tb-odr-action">
                                                                <div class="tb-odr-btns d-none d-sm-inline">
                                                                    <a href="<?= site_url('admin/report/pdf/' . $row->order_id) ?>" target="_blank" class="btn btn-icon btn-white btn-dim btn-sm btn-primary"><em class="icon ni ni-printer-fill"></em></a>
                                                                    <a href="<?= site_url('admin/invoice/detail/' . $row->order_id) ?>" class="btn btn-dim btn-sm btn-primary">View</a>
                                                                </div>
                                                                <a href="<?= site_url('admin/invoice/detail/' . $row->order_id) ?>" class="btn btn-pd-auto d-sm-none"><em class="icon ni ni-chevron-right"></em></a>
                                                            </td>
                                                        </tr><!-- .tb-odr-item -->
                                                    <?php endforeach; ?>

                                                </tbody>
                                            </table>
                                        <?php } ?>
                                </div>
                            </div>
                        </div><!-- .card-preview -->

                    </div><!-- .nk-block -->
                </div><!-- .components-preview -->
            </div>
        </div>
    </div>
</div>