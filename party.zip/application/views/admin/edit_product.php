<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">
                    <div class="nk-block-head nk-block-head-lg wide-sm">
                        <div class="nk-block-head-content">
                            <div class="nk-block-head-sub"><a class="back-to" href="<?= site_url('admin/product/list') ?>"><em class="icon ni ni-arrow-left"></em><span>Components</span></a></div>

                        </div>
                    </div><!-- .nk-block-head -->
                    <div class="nk-block nk-block-lg">
                        <div class="card">
                            <div class="card-inner">
                                <div class="card-head">
                                    <h5 class="card-title">Update Product</h5>
                                </div>
                                <hr>
                                <?php foreach ($product as $row) : ?>
                                    <form action="<?= site_url('admin/product/update') ?>" method="post" class="gy-3">
                                        <div class="row g-3 align-center">
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label class="form-label" for="site-name">Product Name</label>
                                                    <span class="form-note">Specify the name of your product.</span>
                                                </div>
                                            </div>
                                            <div class="col-lg-7">
                                                <div class="form-group">
                                                    <div class="form-control-wrap">
                                                        <input type="hidden" name="id_brg" value="<?= $row->id_brg ?>">
                                                        <input type="text" class="form-control" name="nama_brg" id="site-name" value="<?= $row->nama_brg ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row g-3 align-center">
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label class="form-label">Description Product</label>
                                                    <span class="form-note">Specify the description your products.</span>
                                                </div>
                                            </div>
                                            <div class="col-lg-7">
                                                <div class="form-group">
                                                    <div class="form-control-wrap">
                                                        <input type="text" class="form-control" id="site-email" name="keterangan" value="<?= $row->keterangan ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row g-3 align-center">
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label class="form-label">Product Category</label>
                                                    <span class="form-note">Copyright information of your website.</span>
                                                </div>
                                            </div>
                                            <div class="col-lg-7">
                                                <div class="form-group">
                                                    <div class="form-control-wrap">
                                                        <select name="id_kategori" class="form-control" id="">
                                                            <option hidden value="<?= $row->id_kategori ?>"><?= $row->nama_kategori ?></option>
                                                            <?php foreach ($kategori as $k) : ?>
                                                                <option value="<?= $k->id_kategori ?>"><?= $k->nama_kategori ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row g-3 align-center">
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label class="form-label">Stock</label>
                                                    <span class="form-note">Count for this products.</span>
                                                </div>
                                            </div>
                                            <div class="col-lg-7">
                                                <div class="form-group">
                                                    <div class="form-control-wrap">
                                                        <input type="number" class="form-control" name="stok" id="site-email" value="<?= $row->stok ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row g-3 align-center">
                                            <div class="col-lg-5">
                                                <div class="form-group">
                                                    <label class="form-label">Product Price</label>
                                                    <span class="form-note">Specify price for this products.</span>
                                                </div>
                                            </div>
                                            <div class="col-lg-7">
                                                <div class="form-group">
                                                    <div class="form-control-wrap">
                                                        <input type="number" class="form-control" name="harga" id="site-email" value="<?= $row->harga ?>">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row g-3">
                                            <div class="col-lg-7 offset-lg-5">
                                                <div class="form-group mt-2">
                                                    <button type="submit" class="btn btn-lg btn-primary">Update</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                <?php endforeach; ?>
                            </div>
                        </div><!-- card -->
                    </div><!-- .card-preview -->

                </div><!-- .nk-block -->


            </div><!-- .components-preview -->
        </div>
    </div>
</div>
</div>