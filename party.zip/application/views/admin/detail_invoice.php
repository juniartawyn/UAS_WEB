<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head">
                    <div class="nk-block-between g-3">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">Invoice <strong class="text-primary small">#<?= $invoice->order_id ?></strong></h3>
                            <div class="nk-block-des text-soft">
                                <ul class="list-inline">
                                    <li>Created At: <span class="text-base"><?php echo date('d M, Y, h:i A', strtotime($invoice->transaction_time)); ?></span></li>
                                </ul>
                            </div>
                        </div>
                        <div class="nk-block-head-content">
                            <a href="html/invoice-list.html" class="btn btn-outline-light bg-white d-none d-sm-inline-flex"><em class="icon ni ni-arrow-left"></em><span>Back</span></a>
                            <a href="html/invoice-list.html" class="btn btn-icon btn-outline-light bg-white d-inline-flex d-sm-none"><em class="icon ni ni-arrow-left"></em></a>
                        </div>
                    </div>
                </div><!-- .nk-block-head -->
                <div class="nk-block">
                    <div class="invoice">
                        <div class="invoice-action">
                            <a class="btn btn-icon btn-lg btn-white btn-dim btn-outline-primary" href="<?= site_url('admin/invoice/print/' . $invoice->order_id) ?>" target="_blank"><em class="icon ni ni-printer-fill"></em></a>
                        </div><!-- .invoice-actions -->
                        <div class="invoice-wrap">
                            <div class="invoice-brand text-center">
                                <img src="./images/logo-dark.png" srcset="<?= base_url('assets') ?>/images/logo-dark.png 2x" alt="">
                            </div>
                            <div class="invoice-head">
                                <div class="invoice-contact">
                                    <span class="overline-title">Invoice To</span>
                                    <div class="invoice-contact-info">
                                        <h4 class="title"><?= $invoice->name ?></h4>
                                        <ul class="list-plain">
                                            <?php foreach ($order as $val) : ?>
                                                <li><em class="icon ni ni-map-pin-fill"></em><span><?= $val->alamat ?>, <?= $val->provinsi ?><br><?= $val->kabupaten ?>, Kec. <?= $val->kecamatan ?>, <?= $val->kode_pos ?></span></li>
                                            <?php endforeach; ?>
                                            <li><em class="icon ni ni-call-fill"></em><span>+62 <?= $val->no_hp ?></span></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="invoice-desc">
                                    <h3 class="title">Invoice</h3>
                                    <ul class="list-plain">
                                        <li class="invoice-id"><span>Order ID</span>:<span><?= $invoice->order_id ?></span></li>
                                        <li class="invoice-date"><span>Date</span>:<span><?php echo date('d M, Y', strtotime($invoice->transaction_time)); ?></span></li>
                                    </ul>
                                </div>
                            </div><!-- .invoice-head -->
                            <div class="invoice-bills">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Item ID</th>
                                                <th>Description</th>
                                                <th>Price</th>
                                                <th>Qty</th>
                                                <th>Amount</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $total = 0;
                                            foreach ($pesanan as $row) :
                                                $subtotal = $row->jumlah * $row->harga;
                                                $total += $subtotal;
                                            ?>
                                                <tr>
                                                    <td><?= $row->id_invoice ?></td>
                                                    <td><?= $row->nama_brg ?></td>
                                                    <td>IDR <?= number_format($row->harga, 0, ',', '.') ?></td>
                                                    <td><?= number_format($row->jumlah, 0, ',', '.') ?></td>
                                                    <td>IDR <?= number_format($subtotal, 0, ',', '.') ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="2"></td>
                                                <td colspan="2">Processing fee</td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"></td>
                                                <td colspan="2">TAX</td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"></td>
                                                <td colspan="2">Grand Total</td>
                                                <td><b>IDR <?= number_format($total, 0, ',', '.') ?>,-</b></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <div class="nk-notes ff-italic fs-12px text-soft"> Invoice was created on a computer and is valid without the signature and seal. </div>
                                </div>
                            </div><!-- .invoice-bills -->
                        </div><!-- .invoice-wrap -->
                    </div><!-- .invoice -->
                </div><!-- .nk-block -->
            </div>
        </div>
    </div>
</div>