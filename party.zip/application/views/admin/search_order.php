<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between">
                        <div class="nk-block-head-content">
                            <h3 class="nk-block-title page-title">Orders</h3>
                        </div><!-- .nk-block-head-content -->
                        <div class="nk-block-head-content">
                            <div class="toggle-wrap nk-block-tools-toggle">
                                <a href="#" class="btn btn-icon btn-trigger toggle-expand me-n1" data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
                                <div class="toggle-expand-content" data-content="pageMenu">
                                    <ul class="nk-block-tools g-3">
                                        <?php echo form_open('admin/orders/search') ?>
                                        <li>
                                            <div class="form-control-wrap">
                                                <div class="form-icon form-icon-right">
                                                    <em class="icon ni ni-search"></em>
                                                </div>
                                                <input type="text" class="form-control" name="keyword" id="default-04" placeholder="Quick search by id">
                                            </div>
                                        </li>
                                        <?php echo form_close() ?>
                                    </ul>
                                </div>
                            </div>
                        </div><!-- .nk-block-head-content -->
                    </div><!-- .nk-block-between -->
                </div><!-- .nk-block-head -->
                <div class="nk-block">
                    <div class="card-inner-group">
                        <?php if (empty($search_order)) { ?>
                            <div class="nk-content ">
                                <div class="nk-block nk-block-middle wide-md mx-auto">
                                    <div class="nk-block-content nk-error-ld text-center">
                                        <img class="nk-error-gfx" src="<?= base_url('assets') ?>/be/images/gfx/error-404.svg" alt="">
                                        <div class="wide-xs mx-auto">
                                            <h3 class="nk-error-title">Oops! Data Not Found.</h3>
                                            <p class="nk-error-text">We apologize for not being able to find your search query. Please check the keywords you entered.</p>
                                            <a href="<?= site_url('admin/orders') ?>" class="btn btn-lg btn-primary mt-2">Back To Home</a>
                                        </div>
                                    </div>
                                </div><!-- .nk-block -->
                            </div>
                            <!-- wrap @e -->
                    </div>
                <?php } else { ?>
                    <div class="nk-tb-list is-separate is-medium mb-3">
                        <div class="nk-tb-item nk-tb-head">
                            <div class="nk-tb-col nk-tb-col-check">
                                <div class="custom-control custom-control-sm custom-checkbox notext">
                                    <input type="checkbox" class="custom-control-input" id="oid">
                                    <label class="custom-control-label" for="oid"></label>
                                </div>
                            </div>
                            <div class="nk-tb-col"><span>Order</span></div>
                            <div class="nk-tb-col"><span class="d-none d-sm-block">Status</span></div>
                            <div class="nk-tb-col tb-col-sm"><span>Customer</span></div>
                            <div class="nk-tb-col"><span>Proof of Transaction </span></div>
                            <div class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1 my-n1">
                                    <li>
                                        <div class="drodown">
                                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger me-n1" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li><a href="#"><em class="icon ni ni-edit"></em><span>Update Status</span></a></li>
                                                    <li><a href="#"><em class="icon ni ni-truck"></em><span>Mark as Delivered</span></a></li>
                                                    <li><a href="#"><em class="icon ni ni-money"></em><span>Mark as Paid</span></a></li>
                                                    <li><a href="#"><em class="icon ni ni-report-profit"></em><span>Send Invoice</span></a></li>
                                                    <li><a href="#"><em class="icon ni ni-trash"></em><span>Remove Orders</span></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div><!-- .nk-tb-item -->
                        <?php foreach ($search_order as $row) : ?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col nk-tb-col-check">
                                    <div class="custom-control custom-control-sm custom-checkbox notext">
                                        <input type="checkbox" class="custom-control-input" id="oid01">
                                        <label class="custom-control-label" for="oid01"></label>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
                                    <span class="tb-lead"><a href="#">#<?= $row->order_id ?></a>
                                        <button class="btn btn-sm btn-default" data-clipboard-text="<?= $row->order_id ?>">
                                            <em class="icon ni ni-copy"></em>
                                        </button>
                                    </span>
                                </div>
                                <div class="nk-tb-col">
                                    <?php if ($row->status == "0") { ?>
                                        <span class="dot bg-warning d-sm-none"></span>
                                        <span class="badge badge-sm badge-dot has-bg bg-warning d-none d-sm-inline-flex">On Hold</span>
                                    <?php } else if ($row->status == "1") { ?>
                                        <span class="dot bg-success d-sm-none"></span>
                                        <span class="badge badge-sm badge-dot has-bg bg-success d-none d-sm-inline-flex">Success</span>
                                    <?php } ?>
                                </div>
                                <div class="nk-tb-col tb-col-sm">
                                    <span class="tb-sub"><?= $row->nama_pengguna ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <?php if (empty($row->gambar)) { ?>
                                        <em class="icon ni ni-alert-circle-fill text-danger"></em>&nbsp; <span class="text-danger">Belum upload bukti</span>
                                    <?php } else { ?>
                                        <em class="icon ni ni-link-alt text-primary"></em>&nbsp; <a href="<?= base_url() . '/uploads/' . $row->gambar ?>">Lihat Bukti </a>
                                    <?php } ?>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-1">

                                        <li class="nk-tb-action-hidden"><a href="<?= site_url('admin/orders/detail/' . $row->order_id) ?>" class="btn btn-icon btn-trigger btn-tooltip" title="View Order">
                                                <em class="icon ni ni-eye"></em></a></li>
                                        <li>
                                            <div class="drodown me-n1">
                                                <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li><a href="<?= site_url('admin/orders/detail/' . $row->order_id) ?>"><em class="icon ni ni-eye"></em><span>Order Details</span></a></li>
                                                        <?php if ($row->status == "0") { ?>
                                                            <li><a href="<?= site_url('admin/orders/confirm/' . $row->order_id) ?>"><em class="icon ni ni-money"></em><span>Mark as Paid</span></a></li>
                                                        <?php } else if ($row->status == "1") { ?>
                                                        <?php } ?>
                                                        <li><a href="#"><em class="icon ni ni-trash"></em><span>Remove Order</span></a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div><!-- .nk-tb-item -->
                        <?php endforeach; ?>
                    </div><!-- .nk-tb-list -->
                <?php } ?>
                </div><!-- .nk-block -->
            </div>
        </div>
    </div>
</div>