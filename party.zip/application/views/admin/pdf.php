<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    
    <!-- Page Title  -->
    <title>Invoice Print | NOOKX</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/be/assets/css/dashlite.css?ver=3.1.1">
    <link id="skin-default" rel="stylesheet" href="<?= base_url('assets') ?>/be/assets/css/theme.css?ver=3.1.1">
</head>

<body class="bg-white" onload="printPromot()">
    <div class="nk-block">
        <div class="invoice invoice-print">
            <div class="invoice-wrap">
                <div class="invoice-brand text-center">
                    <img src="<?= base_url('assets') ?>/be/images/logo-dark.png" srcset="<?= base_url('assets') ?>/be/images/logo-dark2x.png 2x" alt="">
                </div>
                <div class="invoice-head">
                    <div class="invoice-contact">
                        <span class="overline-title">Invoice To</span>
                        <div class="invoice-contact-info">
                            <h4 class="title"><?= $invoice->name ?></h4>
                            <ul class="list-plain">
                                <?php foreach ($order as $val) : ?>
                                    <li><em class="icon ni ni-map-pin-fill"></em><span><?= $val->alamat ?>, <?= $val->provinsi ?><br><?= $val->kabupaten ?>, Kec. <?= $val->kecamatan ?>, <?= $val->kode_pos ?></span></li>
                                <?php endforeach; ?>
                                <li><em class="icon ni ni-call-fill"></em><span>+62 <?= $val->no_hp ?></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="invoice-desc">
                        <h3 class="title">Invoice</h3>
                        <ul class="list-plain">
                            <li class="invoice-id"><span>Order ID</span>:<span><?= $invoice->order_id ?></span></li>
                            <li class="invoice-date"><span>Date</span>:<span><?php echo date('d M, Y', strtotime($invoice->transaction_time)); ?></span></li>
                        </ul>
                    </div>
                </div><!-- .invoice-head -->
                <div class="invoice-bills">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Item ID</th>
                                    <th>Description</th>
                                    <th>Price</th>
                                    <th>Qty</th>
                                    <th>Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $total = 0;
                                foreach ($pesanan as $row) :
                                    $subtotal = $row->jumlah * $row->harga;
                                    $total += $subtotal;
                                ?>
                                    <tr>
                                        <td><?= $row->id_invoice ?></td>
                                        <td><?= $row->nama_brg ?></td>
                                        <td>IDR <?= number_format($row->harga, 0, ',', '.') ?></td>
                                        <td><?= number_format($row->jumlah, 0, ',', '.') ?></td>
                                        <td>IDR <?= number_format($subtotal, 0, ',', '.') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="2"></td>
                                    <td colspan="2">Processing fee</td>
                                    <td>-</td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                    <td colspan="2">TAX</td>
                                    <td>-</td>
                                </tr>
                                <tr>
                                    <td colspan="2"></td>
                                    <td colspan="2">Grand Total</td>
                                    <td><b>IDR <?= number_format($total, 0, ',', '.') ?>,-</b></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div><!-- .invoice-bills -->
            </div><!-- .invoice-wrap -->
        </div><!-- .invoice -->
    </div><!-- .nk-block -->
    <!-- <script>
        function printPromot() {
            window.print();
        }
    </script> -->
</body>

</html>