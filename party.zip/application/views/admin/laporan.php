<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">
                    <div class="nk-block-head nk-block-head-lg wide-sm">
                        <div class="nk-block-head-content">
                            <div class="nk-block-head-sub"><a class="back-to" href="html/components.html"><em class="icon ni ni-arrow-left"></em><span>Components</span></a></div>

                        </div>
                    </div><!-- .nk-block-head -->
                    <div class="nk-block nk-block-lg">
                        <div class="nk-block-head">
                            <div class="nk-block-head-content">
                                <h4 class="title nk-block-title">Filter Pencarian</h4>
                                
                            </div>
                        </div>
                        <div class="card card-bordered card-preview">
                            <div class="card-inner">
                                <div class="preview-block">
                                    <form method="post" action="<?php echo base_url('admin/report/') ?>">
                                        <div class="row gy-4">
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="form-label" for="default-01">Mulai Tanggal</label>
                                                    <div class="form-control-wrap">
                                                        <input type="date" name="dari" class="form-control" id="default-01" placeholder="Input placeholder">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label class="form-label" for="default-01">Sampai Tanggal</label>
                                                    <div class="form-control-wrap">
                                                        <input type="date" name="sampai" class="form-control" id="default-01" placeholder="Input placeholder">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <hr class="preview-hr">
                                        <button type="submit" class="btn btn-sm btn-primary"><em class="icon ni ni-filter"></em>&nbsp; Filter</button>
                                    </form>
                                </div>
                            </div>
                        </div><!-- .card-preview -->

                    </div><!-- .nk-block -->
                </div><!-- .components-preview -->
            </div>
        </div>
    </div>
</div>