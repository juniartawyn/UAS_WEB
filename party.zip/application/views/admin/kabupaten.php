<div class="nk-content ">
    <div class="container-fluid">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="components-preview wide-md mx-auto">
                    <div class="nk-block-head nk-block-head-lg wide-sm">
                        <div class="nk-block-head-content">
                            <div class="nk-block-head-sub"><a class="back-to" href="html/components.html"><em class="icon ni ni-arrow-left"></em><span>Components</span></a></div>

                        </div>
                    </div><!-- .nk-block-head -->
                    <div class="nk-block nk-block-lg">
                        <div class="nk-block-head">
                            <div class="nk-block-head-content">
                                <h4 class="nk-block-title">Daftar Kabupaten <button style="float: right;" class="btn btn-sm btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#modalForm">Tambah Data</button></h4>
                            </div>
                        </div>
                        <table class="datatable-init nowrap nk-tb-list is-separate" data-auto-responsive="false">
                            <thead>
                                <tr class="nk-tb-item nk-tb-head">
                                    <th class="nk-tb-col nk-tb-col-check">
                                        <div class="custom-control custom-control-sm custom-checkbox notext">
                                            <input type="checkbox" class="custom-control-input" id="puid">
                                            <label class="custom-control-label" for="puid"></label>
                                        </div>
                                    </th>
                                    <th class="nk-tb-col"><span>Province Name</span></th>
                                    <th class="nk-tb-col nk-tb-col-tools">
                                        <ul class="nk-tb-actions gx-1 my-n1">
                                            <li class="me-n1">
                                                <div class="dropdown">
                                                    <span>Action</span>
                                                </div>
                                            </li>
                                        </ul>
                                    </th>
                                </tr><!-- .nk-tb-item -->
                            </thead>
                            <tbody>
                                <?php foreach ($kab as $row) : ?>
                                    <tr class="nk-tb-item">
                                        <td class="nk-tb-col nk-tb-col-check">
                                            <div class="custom-control custom-control-sm custom-checkbox notext">
                                                <input type="checkbox" class="custom-control-input" id="puid1">
                                                <label class="custom-control-label" for="puid1"></label>
                                            </div>
                                        </td>
                                        <td class="nk-tb-col">
                                            <span class="tb-sub"><?= $row->kabupaten ?></span>
                                        </td>
                                        <td class="nk-tb-col nk-tb-col-tools">
                                            <ul class="nk-tb-actions gx-1 my-n1">
                                                <li class="me-n1">
                                                    <div class="dropdown">
                                                        <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <ul class="link-list-opt no-bdr">
                                                                <li><a data-bs-toggle="modal" data-bs-target="#modalUpdate<?= $row->id_kabupaten ?>"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
                                                                <li><a href="<?php echo base_url('admin/kabupaten/delete/' . $row->id_kabupaten) ?>"><em class="icon ni ni-trash"></em><span>Remove</span></a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </td>
                                    </tr><!-- .nk-tb-item -->
                                <?php endforeach; ?>
                            </tbody>
                        </table><!-- .nk-tb-list -->
                    </div> <!-- nk-block -->

                </div><!-- .components-preview -->
            </div>
        </div>
    </div>
</div>

<!-- Modal Form -->
<div class="modal fade" id="modalForm">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Kabupaten Info</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <form action="<?= base_url('admin/kabupaten/insert') ?>" method="post" class="form-validate is-alter">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label" for="full-name">Kabupaten Name</label>
                        <div class="form-control-wrap">
                            <input type="text" class="form-control" name="kabupaten" id="full-name" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="full-name">Province Name</label>
                        <div class="form-control-wrap">
                            <select name="id_provinsi" class="form-control">
                                <option hidden>Pilih Provinsi</option>
                                <?php foreach ($prov as $p) : ?>
                                    <option value="<?= $p->id_provinsi ?>"><?= $p->provinsi ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="submit" class="btn btn-lg btn-primary">Save Informations</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Modal Form Update -->
<?php foreach ($kab as $row) : ?>
    <div class="modal fade" id="modalUpdate<?= $row->id_kabupaten ?>">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Kabupaten Info</h5>
                    <a href="#" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <em class="icon ni ni-cross"></em>
                    </a>
                </div>
                <form action="<?= base_url('admin/kabupaten/update') ?>" method="post" class="form-validate is-alter">
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="form-label" for="full-name">Kabupaten Name</label>
                            <div class="form-control-wrap">
                                <input type="hidden" name="id_kabupaten" value="<?= $row->id_kabupaten ?>">
                                <input type="text" class="form-control" name="kabupaten" id="full-name" value="<?= $row->kabupaten ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="full-name">Province Name</label>
                            <div class="form-control-wrap">
                                <select name="id_provinsi" class="form-control">
                                    <option value="<?= $row->id_provinsi ?>" hidden><?= $row->provinsi ?></option>
                                    <?php foreach ($prov as $p) : ?>
                                        <option value="<?= $p->id_provinsi ?>"><?= $p->provinsi ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="submit" class="btn btn-lg btn-primary">Save Informations</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>