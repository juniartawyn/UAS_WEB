<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    
    <!-- Page Title  -->
    <title>Invoice Print | NOOKX</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/be/assets/css/dashlite.css?ver=3.1.1">
    <link id="skin-default" rel="stylesheet" href="<?= base_url('assets') ?>/be/assets/css/theme.css?ver=3.1.1">
</head>

<body class="bg-white" onload="printPromot()">
    <div class="nk-block">
        <div class="invoice invoice-print">
            <div class="invoice-wrap">
                
                <div class="invoice-head">
                    <div class="invoice-contact">
                        <span class="overline-title">Laporan Keseluruhan</span>
                        <hr>
                    </div>
                </div><!-- .invoice-head -->
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Customer</th>
                                <th>Transaction Time</th>
                                <th>Channel</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1;
                            foreach ($data as $row) :
                            ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $row->name ?></td>
                                    <td><?= $row->transaction_time ?></td>
                                    <td><?= $row->payment_method ?></td>
                                    <td>
                                        <?php if ($row->status == "0") { ?>
                                            <span class="tb-odr-status">
                                                <span class="badge badge-dot bg-warning">Pending</span>
                                            </span>
                                        <?php } else if ($row->status == "1") { ?>
                                            <span class="tb-odr-status">
                                                <span class="badge badge-dot bg-success">Payment Succesfully</span>
                                            </span>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div><!-- .invoice-wrap -->
        </div><!-- .invoice -->
    </div><!-- .nk-block -->
    <!-- <script>
        function printPromot() {
            window.print();
        }
    </script> -->
</body>

</html>