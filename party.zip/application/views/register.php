<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href=".<?= base_url('assets') ?>/be/.<?= base_url('assets') ?>/be/.<?= base_url('assets') ?>/be/">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="<?= base_url('assets') ?>/be/images/favicon.png">
    <!-- Page Title  -->
    <title>Register | NOOKX</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="<?= base_url('assets') ?>/be/assets/css/dashlite.css?ver=3.1.1">
    <link id="skin-default" rel="stylesheet" href="<?= base_url('assets') ?>/be/assets/css/theme.css?ver=3.1.1">
</head>

<body class="nk-body bg-white npc-default pg-auth">
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- wrap @s -->
            <div class="nk-wrap nk-wrap-nosidebar">
                <!-- content @s -->
                <div class="nk-content ">
                    <div class="nk-block nk-block-middle nk-auth-body wide-xs">
                        <div class="brand-logo pb-4 text-center">
                            
                        </div>
                        <div class="card">
                            <div class="card-inner card-inner-lg">
                                <div class="nk-block-head">
                                    <div class="nk-block-head-content">
                                        <h4 class="nk-block-title">Register</h4>
                                        <div class="nk-block-des">
                                            <p>Create New NOOKX Account</p>
                                        </div>
                                    </div>
                                </div>
                                <form action="<?= site_url('register') ?>" method="post">
                                    <div class="form-group">
                                        <label class="form-label" for="name">Full Name</label>
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control form-control-lg" name="nama_pengguna" id="name" value="<?= set_value('nama_pengguna'); ?>" placeholder="Enter your name">
                                            <?= form_error('nama_pengguna', '<div class="text-danger small ml-2 mt-2">', '</div>') ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="email">Email</label>
                                        <div class="form-control-wrap">
                                            <input type="email" class="form-control form-control-lg" name="email" id="email" value="<?= set_value('email'); ?>" placeholder="Enter your email address">
                                            <?= form_error('email', '<div class="text-danger small ml-2 mt-2">', '</div>') ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="email">Phone Number</label>
                                        <div class="form-control-wrap">
                                            <input type="number" class="form-control form-control-lg" name="no_hp" id="no_hp" value="<?= set_value('no_hp'); ?>" placeholder="Enter your Phone Number">
                                            <?= form_error('no_hp', '<div class="text-danger small ml-2 mt-2">', '</div>') ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="email">Username</label>
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control form-control-lg" name="username" id="email" value="<?= set_value('username'); ?>" placeholder="Enter your username">
                                            <?= form_error('username', '<div class="text-danger small ml-2 mt-2">', '</div>') ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="email">Password</label>
                                        <div class="form-control-wrap">
                                            <input type="password" class="form-control form-control-lg" name="password" id="email" placeholder="Enter your Password">
                                            <?= form_error('password', '<div class="text-danger small ml-2 mt-2">', '</div>') ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="email">Confirm Password</label>
                                        <div class="form-control-wrap">
                                            <input type="password" class="form-control form-control-lg" name="confpassword" id="email" placeholder="Confirm your Password">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-lg btn-primary btn-block">Register</button>
                                    </div>
                                </form>
                                <div class="form-note-s2 text-center pt-4"> Already have an account? <a href="<?= base_url('auth') ?>"><strong>Sign in instead</strong></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- wrap @e -->
            </div>
            <!-- content @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- JavaScript -->
    <script src="<?= base_url('assets') ?>/be/assets/js/bundle.js?ver=3.1.1"></script>
    <script src="<?= base_url('assets') ?>/be/assets/js/scripts.js?ver=3.1.1"></script>

</html>