<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Register extends CI_Controller
{

    public function index()
    {
        $this->form_validation->set_rules('nama_pengguna', 'Full Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('no_hp', 'Phone Number', 'required');
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('password', 'Password', 'required|matches[confpassword]');
        $this->form_validation->set_rules('confpassword', 'Password', 'required|matches[password]');

        if ($this->form_validation->run() == FALSE) {
            $data['title'] = 'Create Account';
            $this->load->view('register', $data);
        } else {
            $data = array(
                'id_user'          => '',
                'nama_pengguna'        => $this->input->post('nama_pengguna'),
                'email'            => $this->input->post('email'),
                'no_hp'            => $this->input->post('no_hp'),
                'username'            => $this->input->post('username'),
                'password'         => md5($this->input->post('password')),
                'level'            => 2,
                'avatar'           => 'user.png',
            );

            $this->db->insert('user', $data);
            $_SESSION["sukses"] = 'Anda berhasil melakukan registrasi';
            redirect('auth');
        }
    }
}
