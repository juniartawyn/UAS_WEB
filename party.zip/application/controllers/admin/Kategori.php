<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kategori extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('level') != '1') {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Kategori List';
        $data['kategori'] = $this->db->query("SELECT * FROM category
        order by id_kategori desc")->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/kategori', $data);
        $this->load->view('layout/admin/footer');
    }

    public function insert()
    {

        $nama_kategori     = $this->input->post('nama_kategori');

        $data = array(
            'nama_kategori'     => $nama_kategori
        );

        $this->model_pembayaran->insert($data, 'category');
        $_SESSION["sukses"] = 'Berhasil menambah data';
        redirect('admin/kategori');
    }

    public function update()
    {
        $id_kategori      = $this->input->post('id_kategori');
        $nama_kategori         = $this->input->post('nama_kategori');

        $data = array(
            'nama_kategori'         => $nama_kategori
        );

        $where = array(
            'id_kategori' => $id_kategori
        );

        $this->model_pembayaran->update('category', $data, $where);
        $_SESSION["sukses"] = 'Berhasil mengubah data';
        redirect('admin/kategori');
    }

    public function delete($id)
    {
        $where = array('id_kategori' => $id);
        $this->model_pembayaran->delete($where, 'category');
        $_SESSION["sukses"] = 'Berhasil menghapus data';
        redirect('admin/kategori');
    }
}
