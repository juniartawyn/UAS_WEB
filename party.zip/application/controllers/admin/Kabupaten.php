<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kabupaten extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('level') != '1') {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Kabupaten List';
        $data['prov'] = $this->model_pembayaran->get('provinsi')->result();
        $data['kab'] = $this->db->query("SELECT * FROM kabupaten
        JOIN provinsi ON provinsi.id_provinsi = kabupaten.id_provinsi
        order by id_kabupaten desc")->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/kabupaten', $data);
        $this->load->view('layout/admin/footer');
    }

    public function insert()
    {
        $id_provinsi     = $this->input->post('id_provinsi');
        $kabupaten     = $this->input->post('kabupaten');

        $data = array(
            'id_provinsi'    => $id_provinsi,
            'kabupaten'     => $kabupaten
        );

        $this->model_pembayaran->insert($data, 'kabupaten');
        $_SESSION["sukses"] = 'Berhasil menambah data';
        redirect('admin/kabupaten');
    }

    public function update()
    {
        $id_kabupaten      = $this->input->post('id_kabupaten');
        $id_provinsi         = $this->input->post('id_provinsi');
        $kabupaten         = $this->input->post('kabupaten');

        $data = array(
            'id_provinsi'         => $id_provinsi,
            'kabupaten'         => $kabupaten
        );

        $where = array(
            'id_kabupaten' => $id_kabupaten
        );

        $this->model_pembayaran->update('kabupaten', $data, $where);
        $_SESSION["sukses"] = 'Berhasil mengubah data';
        redirect('admin/kabupaten');
    }

    public function delete($id)
    {
        $where = array('id_kabupaten' => $id);
        $this->model_pembayaran->delete($where, 'kabupaten');
        $_SESSION["sukses"] = 'Berhasil menghapus data';
        redirect('admin/kabupaten');
    }
}
