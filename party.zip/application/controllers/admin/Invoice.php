<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Invoice extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('level') != '1') {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Orders List';
        $data['invoice'] = $this->db->query("SELECT * FROM transaction
        JOIN user ON user.id_user = transaction.id_user
        WHERE transaction.status='1'
        order by order_id desc")->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/invoice', $data);
        $this->load->view('layout/admin/footer');
    }

    public function detail($id_invoice)
    {
        $data['title'] = 'Detail Checkout';
        $data['invoice'] = $this->model_invoice->get_id_invoice($id_invoice);
        $data['pesanan'] = $this->model_invoice->get_id_pesanan($id_invoice);
        $data['order'] = $this->db->query("SELECT * FROM transaction
        JOIN provinsi ON provinsi.id_provinsi = transaction.id_provinsi
        JOIN user ON user.id_user = transaction.id_user
        JOIN kabupaten ON kabupaten.id_kabupaten = transaction.id_kabupaten
        JOIN kecamatan ON kecamatan.id_kecamatan = transaction.id_kecamatan
        WHERE transaction.order_id='$id_invoice'")->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/detail_invoice', $data);
        $this->load->view('layout/admin/footer');
    }

    public function confirm($id)
    {
        $this->db->update('transaction', ['status' => '1'], ['order_id' => $id]);
        $_SESSION["sukses"] = 'Pesanan berhasil di konfirmasi';
        redirect('admin/invoice');
    }

    public function pdf($id_invoice)
    {
        $data['title'] = 'PDF Report';
        $data['invoice'] = $this->model_invoice->get_id_invoice($id_invoice);
        $data['pesanan'] = $this->model_invoice->get_id_pesanan($id_invoice);
        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->filename = "Invoice Bill.pdf";
        $this->pdf->load_view('admin/payment/pdf', $data);
    }
    public function print($id_invoice)
    {
        $data['title'] = 'Detail Checkout';
        $data['invoice'] = $this->model_invoice->get_id_invoice($id_invoice);
        $data['pesanan'] = $this->model_invoice->get_id_pesanan($id_invoice);
        $data['order'] = $this->db->query("SELECT * FROM transaction
        JOIN provinsi ON provinsi.id_provinsi = transaction.id_provinsi
        JOIN user ON user.id_user = transaction.id_user
        JOIN kabupaten ON kabupaten.id_kabupaten = transaction.id_kabupaten
        JOIN kecamatan ON kecamatan.id_kecamatan = transaction.id_kecamatan
        WHERE transaction.order_id='$id_invoice'")->result();
        $this->load->view('admin/print_invoice', $data);
    }

    public function search()
    {
        $data['title'] = 'Search Orders';
        $keyword = $this->input->post('keyword');
        $data['search'] = $this->model_invoice->get_invoice_keyword($keyword);
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/search_invoice', $data);
        $this->load->view('layout/admin/footer');
    }
}
