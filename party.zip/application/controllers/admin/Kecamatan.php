<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Kecamatan extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('level') != '1') {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Kabupaten List';
        $data['kab'] = $this->model_pembayaran->get('kabupaten')->result();
        $data['kec'] = $this->db->query("SELECT * FROM kecamatan
        JOIN kabupaten ON kabupaten.id_kabupaten = kecamatan.id_kabupaten
        order by id_kecamatan desc")->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/kecamatan', $data);
        $this->load->view('layout/admin/footer');
    }

    public function insert()
    {
        $id_kabupaten     = $this->input->post('id_kabupaten');
        $kecamatan     = $this->input->post('kecamatan');

        $data = array(
            'id_kabupaten'    => $id_kabupaten,
            'kecamatan'     => $kecamatan
        );

        $this->model_pembayaran->insert($data, 'kecamatan');
        $_SESSION["sukses"] = 'Berhasil menambah data';
        redirect('admin/kecamatan');
    }

    public function update()
    {
        $id_kecamatan      = $this->input->post('id_kecamatan');
        $id_kabupaten         = $this->input->post('id_kabupaten');
        $kecamatan         = $this->input->post('kecamatan');

        $data = array(
            'id_kabupaten'         => $id_kabupaten,
            'kecamatan'         => $kecamatan
        );

        $where = array(
            'id_kecamatan' => $id_kecamatan
        );

        $this->model_pembayaran->update('kecamatan', $data, $where);
        $_SESSION["sukses"] = 'Berhasil mengubah data';
        redirect('admin/kecamatan');
    }

    public function delete($id)
    {
        $where = array('id_kecamatan' => $id);
        $this->model_pembayaran->delete($where, 'kecamatan');
        $_SESSION["sukses"] = 'Berhasil menghapus data';
        redirect('admin/kecamatan');
    }
}
