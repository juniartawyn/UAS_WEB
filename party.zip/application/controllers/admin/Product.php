<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Product extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('level') != '1') {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Product List';
        $data['kategori'] = $this->model_pembayaran->get('category')->result();
        $data['product'] = $this->db->query("SELECT * FROM product 
        JOIN category ON category.id_kategori = product.id_kategori
        ORDER BY id_brg DESC")->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/product_list', $data);
        $this->load->view('layout/admin/footer');
    }

    public function card()
    {
        $data['title'] = 'Product Card';
        $data['product'] = $this->model_pembayaran->get('product')->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/product_card', $data);
        $this->load->view('layout/admin/footer');
    }

    public function insert()
    {
        $nama_brg     = $this->input->post('nama_brg');
        $keterangan = $this->input->post('keterangan');
        $id_kategori     = $this->input->post('id_kategori');
        $harga         = $this->input->post('harga');
        $stok         = $this->input->post('stok');
        $gambar        = $_FILES['gambar']['name'];
        if ($gambar = '') {
        } else {
            $config['upload_path'] = './uploads';
            $config['allowed_types'] = 'jpg|jpeg|png';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('gambar')) {
                echo "File tidak dapat di upload!";
            } else {
                $gambar = $this->upload->data('file_name');
            }
        }

        $data = array(
            'nama_brg'     => $nama_brg,
            'keterangan'     => $keterangan,
            'id_kategori'     => $id_kategori,
            'harga'     => $harga,
            'stok'     => $stok,
            'gambar'     => $gambar
        );

        $this->model_pembayaran->insert($data, 'product');
        $_SESSION["sukses"] = 'Berhasil menambah data';
        redirect('admin/product');
    }

    public function edit($id)
    {
        $where = array('id_brg' => $id);
        $data['title'] = 'Update Product';
        $data['kategori'] = $this->model_pembayaran->get('category')->result();
        $data['product'] = $this->db->query("SELECT * FROM product 
        JOIN category ON category.id_kategori = product.id_kategori
        WHERE id_brg = '$id'")->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/edit_product', $data);
        $this->load->view('layout/admin/footer');
    }

    public function update()
    {
        $id                = $this->input->post('id_brg');
        $nama_brg         = $this->input->post('nama_brg');
        $keterangan     = $this->input->post('keterangan');
        $id_kategori         = $this->input->post('id_kategori');
        $harga             = $this->input->post('harga');
        $stok             = $this->input->post('stok');

        $data = array(
            'nama_brg'         => $nama_brg,
            'keterangan'     => $keterangan,
            'id_kategori'         => $id_kategori,
            'harga'         => $harga,
            'stok'             => $stok
        );

        $where = array(
            'id_brg' => $id
        );

        $this->model_pembayaran->update('product', $data, $where);
        $_SESSION["sukses"] = 'Berhasil mengubah data';
        redirect('admin/product');
    }

    public function delete($id)
    {
        $where = array('id_brg' => $id);
        $this->model_pembayaran->delete($where, 'product');
        $_SESSION["sukses"] = 'Berhasil menghapus data';
        redirect('admin/product');
    }

    public function search()
    {
        $data['title'] = 'Search Product';
        $keyword = $this->input->post('keyword');
        $data['products'] = $this->model_pembayaran->get_product_keyword($keyword);
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/search_product', $data);
        $this->load->view('layout/admin/footer');
    }
}
