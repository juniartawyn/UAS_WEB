<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('level') != '1') {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Dashboard';
        $transaction = $this->db->query("SELECT * FROM transaction");
        $data['transaction'] = $transaction->num_rows();
        $user = $this->db->query("SELECT * FROM user WHERE user.level='2'");
        $data['user'] = $user->num_rows();
        $data['order'] = $this->db->query("SELECT * FROM transaction
        JOIN user ON user.id_user = transaction.id_user
        WHERE transaction.status='0'
        order by order_id desc LIMIT 5")->result();
        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/dashboard', $data);
        $this->load->view('layout/admin/footer');
    }

    public function history()
    {

        // Get the user ID
        $id_user = $this->session->userdata('id_user');

        // Get the login history for the user
        $data['history'] = $this->model_pembayaran->get_login_history($id_user);

        $data['title'] = 'Login Activity';

        $this->load->view('layout/admin/header', $data);
        $this->load->view('admin/logs', $data);
        $this->load->view('layout/admin/footer');
    }
}
