<?php

class Report extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // library ci
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');

        // jika role tidak sesuai maka akan di lempar ke halaman login
        if ($this->session->userdata('level') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">
			  <strong>Anda belum login!</strong>
			  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			  </button>
			</div>');
            redirect('auth');
        }
    }
    public function index()
    {
        $dari          = $this->input->post('dari');
        $sampai        = $this->input->post('sampai');
        $this->_rules();
        if ($this->form_validation->run() == FALSE) {
            $data['title'] = "Report All Data";

            // menampilkan all data
            $data['data'] = $this->db->query("SELECT * FROM transaction
            JOIN user ON user.id_user = transaction.id_user
            order by order_id desc")->result();
            $this->load->view('layout/admin/header', $data);
            $this->load->view('admin/laporan', $data);
            $this->load->view('layout/admin/footer');
        } else {
            // page pencarian data
            $data['title'] = "Report All Data";

            // menampilkan data berdasarkan range tanggal pencarian
            $data['data'] = $this->db->query("SELECT * FROM transaction
            JOIN user ON user.id_user = transaction.id_user
            WHERE transaction_time AND date(transaction_time) >= '$dari' AND  date(transaction_time) <= '$sampai'")->result();
            $this->load->view('layout/admin/header', $data);
            $this->load->view('admin/laporan_all', $data);
            $this->load->view('layout/admin/footer');
        }
    }

    public function print()
    {
        // funsgi cetak semua data cuti
        $data['data'] = $this->db->query("SELECT * FROM absen 
        JOIN pegawai on pegawai.nip = absen.nip
        JOIN jabatan on jabatan.id_jabatan = pegawai.id_jabatan
        JOIN bagian on bagian.id_bagian = pegawai.id_bagian")->result();
        $this->load->view('admin/laporan/absensi/laporan_all', $data);
    }

    public function report($id)
    {
        // fungsi cetak data cuti berdasarkan id
        $where = array('id_absen' => $id);
        $data['by'] = $this->db->query("SELECT * FROM absen 
        JOIN pegawai on pegawai.nip = absen.nip
        JOIN jabatan on jabatan.id_jabatan = pegawai.id_jabatan
        JOIN bagian on bagian.id_bagian = pegawai.id_bagian
        WHERE absen.id_absen='$id'")->result();
        $this->load->view('admin/laporan/absensi/laporan_by_id', $data);
    }

    public function pdf($id_invoice)
    {
        $data['title'] = 'PDF Report';
        $data['invoice'] = $this->model_invoice->get_id_invoice($id_invoice);
        $data['pesanan'] = $this->model_invoice->get_id_pesanan($id_invoice);
        $data['order'] = $this->db->query("SELECT * FROM transaction
        JOIN provinsi ON provinsi.id_provinsi = transaction.id_provinsi
        JOIN user ON user.id_user = transaction.id_user
        JOIN kabupaten ON kabupaten.id_kabupaten = transaction.id_kabupaten
        JOIN kecamatan ON kecamatan.id_kecamatan = transaction.id_kecamatan
        WHERE transaction.order_id='$id_invoice'")->result();
        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->set_option('isRemoteEnabled', true); // <-- object ini yang perlu kita tambahkan 
        $this->pdf->filename = "Laporan.pdf";
        $this->pdf->load_view('admin/pdf', $data);
    }

    public function pdf_view()
    {
        $data['title'] = 'PDF Report';
        $data['data'] = $this->db->query("SELECT * FROM transaction
        JOIN provinsi ON provinsi.id_provinsi = transaction.id_provinsi
        JOIN user ON user.id_user = transaction.id_user
        JOIN kabupaten ON kabupaten.id_kabupaten = transaction.id_kabupaten
        JOIN kecamatan ON kecamatan.id_kecamatan = transaction.id_kecamatan
        ORDER BY transaction.order_id DESC")->result();
        $this->load->library('pdf');
        $this->pdf->setPaper('A4', 'potrait');
        $this->pdf->set_option('isRemoteEnabled', true); // <-- object ini yang perlu kita tambahkan 
        $this->pdf->filename = "Laporan_all.pdf";
        $this->pdf->load_view('admin/pdf_view', $data);
    }

    public function _rules()
    {
        // fungsi form rules pencarian data
        $this->form_validation->set_rules('dari', 'Dari Tanggal', 'required');
        $this->form_validation->set_rules('sampai', 'Sampai Tanggal', 'required');
    }
}
