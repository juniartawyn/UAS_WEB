<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Id extends CI_Controller
{
	public function index()
	{
		$data['product'] = $this->db->query("SELECT * FROM product
		order by id_brg desc")->result();
		$this->load->view('layout/id/header', $data);
		$this->load->view('home', $data);
		$this->load->view('layout/id/footer');
	}

	public function search()
	{
		$data['title'] = 'Search Product';
		$keyword = $this->input->post('keyword');
		$data['search'] = $this->model_pembayaran->get_prod_keyword($keyword);
		$this->load->view('layout/id/header', $data);
		$this->load->view('search', $data);
		$this->load->view('layout/id/footer');
	}
}
