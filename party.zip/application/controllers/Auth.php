<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function index()
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('auth');
        } else {
            $username     = $this->input->post('username');
            $password     = $this->input->post('password');

            $cek = $this->model_pembayaran->cek_login($username, $password);

            if ($cek == FALSE) {
                $_SESSION["gagal"] = 'Silahkan periksa username dan password anda';
                redirect('auth');
            } else {
                $this->session->set_userdata('level', $cek->level);
                $this->session->set_userdata('nama_pengguna', $cek->nama_pengguna);
                $this->session->set_userdata('email', $cek->email);
                $this->session->set_userdata('id_user', $cek->id_user);
                $this->session->set_userdata('username', $cek->username);
                $this->session->set_userdata('avatar', $cek->avatar);

                // Save the login information to the database
                $ip_address = $this->input->ip_address();
                $user_agent = $this->input->user_agent();
                $this->model_pembayaran->save_login($cek->id_user, $ip_address, $user_agent);


                switch ($cek->level) {
                    case 1:
                        redirect('admin/dashboard');
                        break;
                    case 2:
                        redirect('user/dashboard');
                        break;

                    default:
                        break;
                }
            }
        }
    }

    public function _rules()
    {
        $this->form_validation->set_rules('username', 'username', 'required');
        $this->form_validation->set_rules('password', 'password', 'required');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('auth');
    }
}
