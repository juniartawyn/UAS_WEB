<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('level') != '2') {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['category']  = $this->model_pembayaran->get('category')->result();
        $data['product'] = $this->db->query("SELECT * FROM product
		order by id_brg desc")->result();
        $this->load->view('layout/user/header', $data);
        $this->load->view('user/dashboard', $data);
        $this->load->view('layout/user/footer');
    }

    public function account()
    {
        $id = $this->session->userdata('id_user');
        $data['account'] = $this->db->query("SELECT * FROM user 
        WHERE user.id_user='$id'")->result();
        $this->load->view('layout/user/header', $data);
        $this->load->view('user/account', $data);
        $this->load->view('layout/user/footer');
    }

    public function address()
    {
        $id = $this->session->userdata('id_user');
        $getdata = $this->model_pembayaran->getdataprov('');
        $data['prov'] = $getdata;
        $data['address'] = $this->db->query("SELECT * FROM account
        JOIN user ON user.id_user = account.id_user 
        JOIN provinsi ON provinsi.id_provinsi = account.id_provinsi 
        JOIN kabupaten ON kabupaten.id_kabupaten = account.id_kabupaten 
        JOIN kecamatan ON kecamatan.id_kecamatan = account.id_kecamatan 
        WHERE user.id_user='$id'")->result();
        $this->load->view('layout/user/header', $data);
        $this->load->view('user/address', $data);
        $this->load->view('layout/user/footer');
    }

    function getdatakabupaten()
    {
        $id_provinsi = $this->input->post('provinsi');

        $getdatakab = $this->model_pembayaran->getdatakab($id_provinsi);

        echo json_encode($getdatakab);
    }

    function getdatakecamatan()
    {
        $id_kabupaten = $this->input->post('kabupaten');

        $getdatakec = $this->model_pembayaran->getdatakec($id_kabupaten);

        echo json_encode($getdatakec);
    }

    public function insert_address()
    {
        $id_user     = $this->input->post('id_user');
        $tempat = $this->input->post('tempat');
        $alamat     = $this->input->post('alamat');
        $id_provinsi         = $this->input->post('id_provinsi');
        $id_kabupaten         = $this->input->post('id_kabupaten');
        $id_kecamatan         = $this->input->post('id_kecamatan');
        $kode_pos         = $this->input->post('kode_pos');
        $no_hp         = $this->input->post('no_hp');

        $data = array(
            'id_user'     => $id_user,
            'tempat'     => $tempat,
            'alamat'     => $alamat,
            'id_provinsi'     => $id_provinsi,
            'id_kabupaten'     => $id_kabupaten,
            'id_kecamatan'     => $id_kecamatan,
            'kode_pos'     => $kode_pos,
            'no_hp'     => $no_hp
        );

        $this->model_pembayaran->insert($data, 'account');
        $_SESSION["sukses"] = 'Product berhasil di tambahkan';
        redirect('user/dashboard/address');
    }

    public function cart($id)
    {
        $product = $this->model_pembayaran->find($id);

        $data = array(
            'id'      => $product->id_brg,
            'qty'     => 1,
            'price'   => $product->harga,
            'name'    => $product->nama_brg,
            'options' => array(
                'keterangan' => $product->keterangan,
                'id_kategori' => $product->id_kategori,
                'gambar' => $product->gambar
            )
        );

        $this->cart->insert($data);
        $_SESSION["sukses"] = 'Pesanan telah disimpan di keranjang';
        redirect('user/dashboard');
    }

    public function detail_product($id)
    {
        $where = array('id_brg' => $id);
        $data['detail'] = $this->db->query("SELECT * FROM product WHERE id_brg='$id'")->result();
        $data['title'] = "Detail Product";
        $this->load->view('layout/user/header', $data);
        $this->load->view('detail_product', $data);
        $this->load->view('layout/user/footer');
    }

    public function detail_cart()
    {
        $data['title'] = 'Detail Cart';
        $this->load->view('layout/user/header', $data);
        $this->load->view('user/cart', $data);
        $this->load->view('layout/user/footer');
    }

    public function clear()
    {
        $this->cart->destroy();
        $_SESSION["sukses"] = 'Pesanan berhasil di hapus';
        redirect('user/dashboard');
    }

    public function delete_row($rowid)
    {
        $this->cart->remove($rowid);
        $_SESSION["sukses"] = 'Pesanan berhasil di hapus';
        redirect('user/dashboard/detail_cart');
    }

    public function checkout()
    {
        $data['title'] = 'Checkout Product';
        $id = $this->session->userdata('id_user');
        $getdata = $this->model_pembayaran->getdataprov('');
        $data['prov'] = $getdata;
        $data['akun'] = $this->db->query("SELECT * FROM user
        WHERE user.id_user='$id'")->result();
        $this->load->view('layout/user/header', $data);
        $this->load->view('user/checkout', $data);
        $this->load->view('layout/user/footer');
    }

    public function checkout_proccess()
    {
        $data['title'] = 'Payment Notification';
        $is_processed = $this->model_invoice->index();
        if ($is_processed) {
            $this->cart->destroy();
            redirect('user/dashboard/order');
        } else {
            $_SESSION["gagal"] = 'Maaf, Pesanan Anda Gagal Di Proses!';
        }
    }

    public function order()
    {
        $data['title'] = 'My Orders';
        $id = $this->session->userdata('id_user');
        $data['order'] = $this->db->query("SELECT * FROM transaction
        JOIN user ON user.id_user = transaction.id_user
        JOIN provinsi ON provinsi.id_provinsi = transaction.id_provinsi
        JOIN kabupaten ON kabupaten.id_kabupaten = transaction.id_kabupaten
        JOIN kecamatan ON kecamatan.id_kecamatan = transaction.id_kecamatan
        WHERE user.id_user='$id'
        ORDER BY transaction.id DESC")->result();
        $this->load->view('layout/user/header', $data);
        $this->load->view('user/order', $data);
        $this->load->view('layout/user/footer');
    }

    public function upload()
    {
        $id            = $this->input->post('order_id');
        $gambar        = $_FILES['gambar']['name'];
        if ($gambar = '') {
        } else {
            $config['upload_path'] = './uploads';
            $config['allowed_types'] = 'jpg|jpeg|png';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('gambar')) {
                echo "File tidak dapat di upload!";
            } else {
                $gambar = $this->upload->data('file_name');
            }
        }

        $data = array(
            'gambar'             => $gambar
        );

        $where = array(
            'order_id' => $id
        );

        $this->model_pembayaran->update('transaction', $data, $where);
        redirect('user/dashboard/order');
    }

    public function invoice($id_invoice)
    {
        $data['title'] = 'Detail Checkout';
        $data['invoice'] = $this->model_invoice->get_id_invoice($id_invoice);
        $data['pesanan'] = $this->model_invoice->get_id_pesanan($id_invoice);
        $data['order'] = $this->db->query("SELECT * FROM transaction
        JOIN provinsi ON provinsi.id_provinsi = transaction.id_provinsi
        JOIN kabupaten ON kabupaten.id_kabupaten = transaction.id_kabupaten
        JOIN kecamatan ON kecamatan.id_kecamatan = transaction.id_kecamatan
        WHERE transaction.order_id='$id_invoice'")->result();
        $this->load->view('layout/user/header', $data);
        $this->load->view('user/invoice', $data);
        $this->load->view('layout/user/footer');
    }

    public function search()
    {
        $data['title'] = 'Search Product';
        $keyword = $this->input->post('keyword');
        $data['search'] = $this->model_pembayaran->get_prod_keyword($keyword);
        $this->load->view('layout/user/header', $data);
        $this->load->view('user/search', $data);
        $this->load->view('layout/user/footer');
    }
}
