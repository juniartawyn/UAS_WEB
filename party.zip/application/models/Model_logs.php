<?php
class Model_logs extends CI_Model
{

    public function insert_log($data)
    {
        return $this->db->insert('logs', $data);
    }
}
