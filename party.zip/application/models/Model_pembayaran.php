<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_pembayaran extends CI_Model
{

    public function cek_login()
    {
        $username     = set_value('username');
        $password     = set_value('password');

        $result     = $this->db->where('username', $username)
            ->where('password', md5($password))
            ->limit(1)
            ->get('user');
        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return FALSE;
        }
    }

    public function get($table)
    {
        return $this->db->get($table);
    }

    public function getdataprov()
    {
        $query = $this->db->query("SELECT * FROM provinsi ORDER BY provinsi ASC");
        return $query->result();
    }

    public function getdatakab($id_provinsi)
    {
        $query = $this->db->query("SELECT * FROM kabupaten WHERE id_provinsi = '$id_provinsi' ORDER BY kabupaten ASC");
        return $query->result();
    }

    public function getdatakec($id_kabupaten)
    {
        $query = $this->db->query("SELECT * FROM kecamatan WHERE id_kabupaten = '$id_kabupaten' ORDER BY kecamatan ASC");
        return $query->result();
    }

    public function get_product_keyword($keyword)
    {
        $this->db->select('*');
        $this->db->from('product');
        $this->db->join('category', 'category.id_kategori = product.id_kategori');
        $this->db->like('nama_brg', $keyword);
        $this->db->or_like('harga', $keyword);
        $this->db->or_like('keterangan', $keyword);
        return $this->db->get()->result();
    }

    public function get_prod_keyword($keyword)
    {
        $this->db->select('*');
        $this->db->from('product');
        $this->db->join('category', 'category.id_kategori = product.id_kategori');
        $this->db->like('nama_brg', $keyword);
        $this->db->or_like('harga', $keyword);
        $this->db->or_like('nama_kategori', $keyword);
        $this->db->or_like('keterangan', $keyword);
        return $this->db->get()->result();
    }

    public function save_login($id_user, $ip_address, $user_agent)
    {
        $data = array(
            'id_user' => $id_user,
            'ip_address' => $ip_address,
            'user_agent' => $user_agent,
            'login_time' => date('Y-m-d H:i:s')
        );

        $this->db->insert('logs', $data);
    }

    public function get_login_history($id_user)
    {
        $this->db->where('id_user', $id_user);
        $this->db->order_by('logs.login_time', 'desc');
        $query = $this->db->get('logs');
        return $query->result_array();
    }

    function getData()
    {
        $data_siswa = $this->db->get('siswa');
        return $data_siswa->result();
    }

    public function insert($data, $table)
    {
        $this->db->insert($table, $data);
    }

    public function update($table, $data, $where)
    {
        $this->db->update($table, $data, $where);
    }

    public function delete($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }

    public function find($id)
    {
        $result = $this->db->where('id_brg', $id)
            ->limit(1)
            ->get('product');
        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return array();
        }
    }

    public function count_order()
    {
        $sql = "SELECT count(order_id) as order_id FROM transaction";
        $result = $this->db->query($sql);

        return $result->row()->order_id;
    }

    public function count_pending()
    {
        $sql = "SELECT count(order_id) as order_id FROM transaction WHERE status='0'";
        $result = $this->db->query($sql);

        return $result->row()->order_id;
    }

    public function count_success()
    {
        $sql = "SELECT count(order_id) as order_id FROM transaction WHERE status='1'";
        $result = $this->db->query($sql);

        return $result->row()->order_id;
    }
}
