<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_invoice extends CI_Model
{
    public function index()
    {
        date_default_timezone_set('Asia/Jakarta');
        $order_id = $this->input->post('order_id');
        $id_user = $this->input->post('id_user');
        $name = $this->input->post('name');
        $alamat = $this->input->post('alamat');
        $id_provinsi = $this->input->post('id_provinsi');
        $id_kabupaten = $this->input->post('id_kabupaten');
        $id_kecamatan = $this->input->post('id_kecamatan');
        $kode_pos = $this->input->post('kode_pos');
        $information = $this->input->post('information');
        $payment_method = $this->input->post('payment_method');
        $status = $this->input->post('status');

        $invoice = array(
            'order_id'             => $order_id,
            'id_user'             => $id_user,
            'name'                 => $name,
            'alamat'             => $alamat,
            'id_provinsi'                 => $id_provinsi,
            'id_kabupaten'                 => $id_kabupaten,
            'id_kecamatan'                 => $id_kecamatan,
            'kode_pos'             => $kode_pos,
            'information'             => $information,
            'payment_method'     => $payment_method,
            'status'             => $status,
            'transaction_time'     => date('Y-m-d H:i:s'),
            'payment_limit'     => date('Y-m-d H:i:s', mktime(date('H'), date('i'), date('s'), date('m'), date('d') + 1, date('Y'))),
        );

        $this->db->insert('transaction', $invoice);
        $id_invoice = $this->db->insert_id();

        foreach ($this->cart->contents() as $item) {
            $data = array(
                'id_invoice'     => $order_id,
                'id_user'         => $id_user,
                'id_brg'         => $item['id'],
                'nama_brg'         => $item['name'],
                'jumlah'         => $item['qty'],
                'harga'         => $item['price'],
            );

            $this->db->insert('cart', $data);
        }

        return TRUE;
    }

    public function get_order_keyword($keyword)
    {
        $this->db->select('*');
        $this->db->from('transaction');
        $this->db->join('user', 'user.id_user = transaction.id_user');
        $this->db->like('order_id', $keyword);
        $this->db->or_like('name', $keyword);
        $this->db->or_like('payment_method', $keyword);
        return $this->db->get()->result();
    }

    public function get_invoice_keyword($keyword)
    {
        $this->db->select('*');
        $this->db->from('transaction');
        $this->db->join('user', 'user.id_user = transaction.id_user');
        $this->db->like('order_id', $keyword);
        $this->db->or_like('name', $keyword);
        $this->db->or_like('payment_method', $keyword);
        return $this->db->get()->result();
    }

    public function get()
    {
        $result = $this->db->get('transaction');
        if ($result->num_rows() > 0) {
            return $result->result();
        } else {
            return false;
        }
    }

    public function get_id_invoice($id_invoice)
    {
        $result = $this->db->where('order_id', $id_invoice)->limit(1)->get('transaction');
        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return false;
        }
    }

    public function get_id_pesanan($id_invoice)
    {
        $result = $this->db->where('id_invoice', $id_invoice)->get('cart');
        if ($result->num_rows() > 0) {
            return $result->result();
        } else {
            return false;
        }
    }
}
