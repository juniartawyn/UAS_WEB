-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 10 Jan 2023 pada 12.18
-- Versi server: 10.4.22-MariaDB
-- Versi PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_party`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `account`
--

CREATE TABLE `account` (
  `id_account` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `tempat` varchar(128) NOT NULL,
  `alamat` text NOT NULL,
  `id_provinsi` int(11) NOT NULL,
  `id_kabupaten` int(11) NOT NULL,
  `id_kecamatan` int(11) NOT NULL,
  `kode_pos` varchar(15) NOT NULL,
  `no_hp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `id_user` varchar(25) NOT NULL,
  `id_invoice` varchar(30) NOT NULL,
  `id_brg` int(11) NOT NULL,
  `nama_brg` varchar(255) NOT NULL,
  `jumlah` int(3) NOT NULL,
  `harga` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `cart`
--

INSERT INTO `cart` (`id`, `id_user`, `id_invoice`, `id_brg`, `nama_brg`, `jumlah`, `harga`) VALUES
(14, '14', '545929', 11, 'Jacket Erigo', 1, 350000),
(15, '19', '694803', 11, 'Jacket Erigo', 1, 350000),
(16, '20', '885154', 11, 'Jacket Erigo', 1, 350000),
(17, '20', '216840', 17, 'Baju Kemeja Flanel Pria', 1, 90000),
(18, '20', '1029484', 55, 'Sepatu Sneakers Running Pria Dane and Dine 992 NB', 1, 180000);

--
-- Trigger `cart`
--
DELIMITER $$
CREATE TRIGGER `pesanan_penjualan` AFTER INSERT ON `cart` FOR EACH ROW BEGIN
	UPDATE product SET stok = stok-NEW.jumlah
    WHERE id_brg = NEW.id_brg;
    END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `category`
--

CREATE TABLE `category` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `category`
--

INSERT INTO `category` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Jaket'),
(2, 'Baju'),
(6, 'Sepatu'),
(7, 'Kemeja');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kabupaten`
--

CREATE TABLE `kabupaten` (
  `id_kabupaten` int(11) NOT NULL,
  `id_provinsi` int(11) NOT NULL,
  `kabupaten` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kabupaten`
--

INSERT INTO `kabupaten` (`id_kabupaten`, `id_provinsi`, `kabupaten`) VALUES
(1, 22, 'Kota Denpasar'),
(2, 17, 'Kabupaten Lebak'),
(3, 17, 'Kabupaten Pandeglang'),
(4, 17, 'Kabupaten Serang'),
(5, 17, 'Kabupaten Tangerang'),
(6, 17, 'Kota Cilegon'),
(7, 17, 'Kota Serang'),
(8, 17, 'Kota Tangerang'),
(9, 17, 'Kota Tangerang Selatan'),
(11, 1, 'Kabupaten Aceh Barat'),
(12, 1, 'Kabupaten Aceh Barat Daya'),
(13, 1, 'Kabupaten Aceh Besar'),
(14, 1, 'Kabupaten Aceh Jaya'),
(15, 1, 'Kabupaten Aceh Selatan'),
(16, 1, 'Kabupaten Aceh Singkil'),
(17, 1, 'Kabupaten Aceh Tamiang'),
(18, 1, 'Kabupaten Aceh Tengah'),
(19, 1, 'Kabupaten Aceh Tenggara'),
(20, 1, 'Kabupaten Aceh Timur'),
(21, 1, 'Kabupaten Aceh Utara'),
(22, 1, 'Kabupaten Bener Meriah'),
(23, 1, 'Kabupaten Bireuen'),
(24, 1, 'Kabupaten Gayo Lues'),
(25, 1, 'Kabupaten Nagan Raya'),
(26, 1, 'Kabupaten Pidie'),
(27, 1, 'Kabupaten Pidie Jaya'),
(28, 1, 'Kabupaten Simeulue'),
(29, 1, 'Kota Banda Aceh'),
(30, 1, 'Kota Langsa'),
(31, 1, 'Kota Lhokseumawe'),
(32, 1, 'Kota Sabang'),
(33, 1, 'Kota Subulussalam'),
(34, 2, 'Kabupaten Asahan'),
(35, 2, 'Kabupaten Batubara'),
(36, 2, 'Kabupaten Dairi'),
(37, 2, 'Kabupaten Deli Serdang'),
(38, 2, 'Kabupaten Humbang Hasundutan'),
(39, 2, 'Kabupaten Karo'),
(40, 2, 'Kabupaten Labuhanbatu'),
(41, 2, 'Kabupaten Labuhanbatu Selatan'),
(42, 2, 'Kabupaten Labuhanbatu Utara'),
(43, 2, 'Kabupaten Langkat'),
(44, 2, 'Kabupaten Mandailing Natal'),
(45, 2, 'Kabupaten Nias'),
(46, 2, 'Kabupaten Nias Barat'),
(47, 2, 'Kabupaten Nias Selatan'),
(48, 2, 'Kabupaten Nias Utara'),
(49, 2, 'Kabupaten Padang Lawas'),
(50, 2, 'Kabupaten Padang Lawas Utara'),
(51, 2, 'Kabupaten Pakpak Bharat'),
(52, 2, 'Kabupaten Samosir'),
(53, 2, 'Kabupaten Serdang Bedagai'),
(54, 2, 'Kabupaten Simalungun'),
(55, 2, 'Kabupaten Tapanuli Selatan'),
(56, 2, 'Kabupaten Tapanuli Tengah'),
(57, 2, 'Kabupaten Tapanuli Utara'),
(58, 2, 'Kabupaten Toba Samosir'),
(59, 2, 'Kota Binjai'),
(60, 2, 'Kota Gunungsitoli'),
(61, 2, 'Kota Medan'),
(62, 2, 'Kota Padangsidempuan'),
(63, 2, 'Kota Pematangsiantar'),
(64, 2, 'Kota Sibolga'),
(65, 2, 'Kota Tanjungbalai'),
(66, 2, 'Kota Tebing Tinggi'),
(67, 3, 'Kabupaten Banyuasin'),
(68, 3, 'Kabupaten Empat Lawang'),
(69, 3, 'Kabupaten Lahat'),
(70, 3, 'Kabupaten Muara Enim'),
(71, 3, 'Kabupaten Musi Banyuasin'),
(72, 3, 'Kabupaten Musi Rawas'),
(73, 3, 'Kabupaten Musi Rawas Utara'),
(74, 3, 'Kabupaten Ogan Ilir'),
(75, 3, 'Kabupaten Ogan Komering Ilir'),
(76, 3, 'Kabupaten Ogan Komering Ulu'),
(77, 3, 'Kabupaten Ogan Komering Ulu Selatan'),
(78, 3, 'Kabupaten Ogan Komering Ulu Timur'),
(79, 3, 'Kabupaten Penukal Abab Lematang Ilir'),
(80, 3, 'Kota Lubuklinggau'),
(81, 3, 'Kota Pagar Alam'),
(82, 3, 'Kota Palembang'),
(83, 3, 'Kota Prabumulih'),
(84, 4, 'Kabupaten Agam'),
(85, 4, 'Kabupaten Dharmasraya'),
(86, 4, 'Kabupaten Kepulauan Mentawai'),
(87, 4, 'Kabupaten Lima Puluh Kota'),
(88, 4, 'Kabupaten Padang Pariaman'),
(89, 4, 'Kabupaten Pasaman'),
(90, 4, 'Kabupaten Pasaman Barat'),
(91, 4, 'Kabupaten Pesisir Selatan'),
(92, 4, 'Kabupaten Sijunjung'),
(93, 4, 'Kabupaten Solok'),
(94, 4, 'Kabupaten Solok Selatan'),
(95, 4, 'Kabupaten Tanah Datar'),
(96, 4, 'Kota Bukittinggi'),
(97, 4, 'Kota Padang'),
(98, 4, 'Kota Padangpanjang'),
(99, 4, 'Kota Pariaman'),
(100, 4, 'Kota Payakumbuh'),
(101, 4, 'Kota Sawahlunto'),
(102, 4, 'Kota Solok'),
(103, 5, 'Kabupaten Bengkulu Selatan'),
(104, 5, 'Kabupaten Bengkulu Tengah'),
(105, 5, 'Kabupaten Bengkulu Utara'),
(106, 5, 'Kabupaten Kaur'),
(107, 5, 'Kabupaten Kepahiang'),
(108, 5, 'Kabupaten Lebong'),
(109, 5, 'Kabupaten Mukomuko'),
(110, 5, 'Kabupaten Rejang Lebong'),
(111, 5, 'Kabupaten Seluma'),
(112, 5, 'Kota Bengkulu'),
(113, 7, 'Kabupaten Bintan'),
(114, 7, 'Kabupaten Karimun'),
(115, 7, 'Kabupaten Kepulauan Anambas'),
(116, 7, 'Kabupaten Lingga'),
(117, 7, 'Kabupaten Natuna'),
(118, 7, 'Kota Batam'),
(119, 7, 'Kota Tanjung Pinang'),
(120, 6, 'Kabupaten Bengkalis'),
(121, 6, 'Kabupaten Indragiri Hilir'),
(122, 6, 'Kabupaten Indragiri Hulu'),
(123, 6, 'Kabupaten Kampar'),
(124, 6, 'Kabupaten Kepulauan Meranti'),
(125, 6, 'Kabupaten Kuantan Singingi'),
(126, 6, 'Kabupaten Pelalawan'),
(127, 6, 'Kabupaten Rokan Hilir'),
(128, 6, 'Kabupaten Rokan Hulu'),
(129, 6, 'Kabupaten Siak'),
(130, 6, 'Kota Dumai'),
(131, 6, 'Kota Pekanbaru'),
(132, 8, 'Kabupaten Batanghari'),
(133, 8, 'Kabupaten Bungo'),
(134, 8, 'Kabupaten Kerinci'),
(135, 8, 'Kabupaten Merangin'),
(136, 8, 'Kabupaten Muaro Jambi'),
(137, 8, 'Kabupaten Sarolangun'),
(138, 8, 'Kabupaten Tanjung Jabung Barat'),
(139, 8, 'Kabupaten Tanjung Jabung Timur'),
(140, 8, 'Kabupaten Tebo'),
(141, 8, 'Kota Jambi'),
(142, 8, 'Kota Sungai Penuh'),
(143, 9, 'Kabupaten Lampung Tengah'),
(144, 9, 'Kabupaten Lampung Utara'),
(145, 9, 'Kabupaten Lampung Selatan'),
(146, 9, 'Kabupaten Lampung Barat'),
(147, 9, 'Kabupaten Lampung Timur'),
(148, 9, 'Kabupaten Mesuji'),
(149, 9, 'Kabupaten Pesawaran'),
(150, 9, 'Kabupaten Pesisir Barat'),
(151, 9, 'Kabupaten Pringsewu'),
(152, 9, 'Kabupaten Tulang Bawang'),
(153, 9, 'Kabupaten Tulang Bawang Barat'),
(154, 9, 'Kabupaten Tanggamus'),
(155, 9, 'Kabupaten Way Kanan'),
(156, 9, 'Kota Bandar Lampung'),
(157, 9, 'Kota Metro'),
(158, 10, 'Kabupaten Bangka'),
(159, 10, 'Kabupaten Bangka Barat'),
(160, 10, 'Kabupaten Bangka Selatan'),
(161, 10, 'Kabupaten Bangka Tengah'),
(162, 10, 'Kabupaten Belitung'),
(163, 10, 'Kabupaten Belitung Timur'),
(164, 10, 'Kota Pangkal Pinang'),
(165, 11, 'Kabupaten Berau'),
(166, 11, 'Kabupaten Kutai Barat'),
(167, 11, 'Kabupaten Kutai Kartanegara'),
(168, 11, 'Kabupaten Kutai Timur'),
(169, 11, 'Kabupaten Mahakam Ulu'),
(170, 11, 'Kabupaten Paser'),
(171, 11, 'Kabupaten Penajam Paser Utara'),
(172, 11, 'Kota Balikpapan'),
(173, 11, 'Kota Bontang'),
(174, 11, 'Kota Samarinda'),
(175, 12, 'Kabupaten Bengkayang'),
(176, 12, 'Kabupaten Kapuas Hulu'),
(177, 12, 'Kabupaten Kayong Utara'),
(178, 12, 'Kabupaten Ketapang'),
(179, 12, 'Kabupaten Kubu Raya'),
(180, 12, 'Kabupaten Landak'),
(181, 12, 'Kabupaten Melawi'),
(182, 12, 'Kabupaten Mempawah'),
(183, 12, 'Kabupaten Sambas'),
(184, 12, 'Kabupaten Sanggau'),
(185, 12, 'Kabupaten Sekadau'),
(186, 12, 'Kabupaten Sintang'),
(187, 12, 'Kota Pontianak'),
(188, 12, 'Kota Singkawang'),
(189, 13, 'Kabupaten Barito Selatan'),
(190, 13, 'Kabupaten Barito Timur'),
(191, 13, 'Kabupaten Barito Utara'),
(192, 13, 'Kabupaten Gunung Mas'),
(193, 13, 'Kabupaten Kapuas'),
(194, 13, 'Kabupaten Katingan'),
(195, 13, 'Kabupaten Kotawaringin Barat'),
(196, 13, 'Kabupaten Kotawaringin Timur'),
(197, 13, 'Kabupaten Lamandau'),
(198, 13, 'Kabupaten Murung Raya'),
(199, 13, 'Kabupaten Pulang Pisau'),
(200, 13, 'Kabupaten Sukamara'),
(201, 13, 'Kabupaten Seruyan'),
(202, 13, 'Kota Palangka Raya'),
(203, 14, 'Kabupaten Balangan'),
(204, 14, 'Kabupaten Banjar'),
(205, 14, 'Kabupaten Barito Kuala'),
(206, 14, 'Kabupaten Hulu Sungai Selatan'),
(207, 14, 'Kabupaten Hulu Sungai Tengah'),
(208, 14, 'Kabupaten Hulu Sungai Utara'),
(209, 14, 'Kabupaten Kotabaru'),
(210, 14, 'Kabupaten Tabalong'),
(211, 14, 'Kabupaten Tanah Bumbu'),
(212, 14, 'Kabupaten Tanah Laut'),
(213, 14, 'Kabupaten Tapin'),
(214, 14, 'Kota Banjarbaru'),
(215, 14, 'Kota Banjarmasin'),
(216, 15, 'Kabupaten Bulungan'),
(217, 15, 'Kabupaten Malinau'),
(218, 15, 'Kabupaten Nunukan'),
(219, 15, 'Kabupaten Tana Tidung'),
(220, 15, 'Kota Tarakan'),
(221, 16, 'Jakarta Barat'),
(222, 16, 'Jakarta Pusat'),
(223, 16, 'Jakarta Selatan'),
(224, 16, 'Jakarta Timur'),
(225, 16, 'Jakarta Utara'),
(226, 16, 'Kepulauan Seribu'),
(227, 18, 'Kabupaten Bandung'),
(228, 18, 'Kabupaten Bandung Barat'),
(229, 18, 'Kabupaten Bekasi'),
(230, 18, 'Kabupaten Bogor'),
(231, 18, 'Kabupaten Ciamis'),
(232, 18, 'Kabupaten Cianjur'),
(233, 18, 'Kabupaten Cirebon'),
(234, 18, 'Kabupaten Garut'),
(235, 18, 'Kabupaten Indramayu'),
(236, 18, 'Kabupaten Karawang'),
(237, 18, 'Kabupaten Kuningan'),
(238, 18, 'Kabupaten Majalengka'),
(239, 18, 'Kabupaten Pangandaran'),
(240, 18, 'Kabupaten Purwakarta'),
(241, 18, 'Kabupaten Subang'),
(242, 18, 'Kabupaten Sukabumi'),
(243, 18, 'Kabupaten Sumedang'),
(244, 18, 'Kabupaten Tasikmalaya'),
(245, 18, 'Kota Bandung'),
(246, 18, 'Kota Banjar'),
(247, 18, 'Kota Bekasi'),
(248, 18, 'Kota Bogor'),
(249, 18, 'Kota Cimahi'),
(250, 18, 'Kota Cirebon'),
(251, 18, 'Kota Depok'),
(252, 18, 'Kota Sukabumi'),
(253, 18, 'Kota Tasikmalaya'),
(254, 19, 'Kabupaten Banjarnegara'),
(255, 19, 'Kabupaten Banyumas'),
(256, 19, 'Kabupaten Batang'),
(257, 19, 'Kabupaten Blora'),
(258, 19, 'Kabupaten Boyolali'),
(259, 19, 'Kabupaten Brebes'),
(260, 19, 'Kabupaten Cilacap'),
(261, 19, 'Kabupaten Demak'),
(262, 19, 'Kabupaten Grobogan'),
(263, 19, 'Kabupaten Jepara'),
(264, 19, 'Kabupaten Karanganyar'),
(265, 19, 'Kabupaten Kebumen'),
(266, 19, 'Kabupaten Kendal'),
(267, 19, 'Kabupaten Klaten'),
(268, 19, 'Kabupaten Kudus'),
(269, 19, 'Kabupaten Magelang'),
(270, 19, 'Kabupaten Pati'),
(271, 19, 'Kabupaten Pekalongan'),
(272, 19, 'Kabupaten Pemalang'),
(273, 19, 'Kabupaten Purbalingga'),
(274, 19, 'Kabupaten Purworejo'),
(275, 19, 'Kabupaten Rembang'),
(276, 19, 'Kabupaten Semarang'),
(277, 19, 'Kabupaten Sragen'),
(278, 19, 'Kabupaten Sukoharjo'),
(279, 19, 'Kabupaten Tegal'),
(280, 19, 'Kabupaten Temanggung'),
(281, 19, 'Kabupaten Wonogiri'),
(282, 19, 'Kabupaten Wonosobo'),
(283, 19, 'Kota Magelang'),
(284, 19, 'Kota Pekalongan'),
(285, 19, 'Kota Salatiga'),
(286, 19, 'Kota Semarang'),
(287, 19, 'Kota Surakarta'),
(288, 19, 'Kota Tegal'),
(289, 20, 'Kabupaten Bantul'),
(290, 20, 'Kabupaten Gunungkidul'),
(291, 20, 'Kabupaten Kulon Progo'),
(292, 20, 'Kabupaten Sleman'),
(293, 20, 'Kota Yogyakarta'),
(294, 21, 'Kabupaten Bangkalan'),
(295, 21, 'Kabupaten Banyuwangi'),
(296, 21, 'Kabupaten Blitar'),
(297, 21, 'Kabupaten Bojonegoro'),
(298, 21, 'Kabupaten Bondowoso'),
(299, 21, 'Kabupaten Gresik'),
(300, 21, 'Kabupaten Jember'),
(301, 21, 'Kabupaten Jombang'),
(302, 21, 'Kabupaten Kediri'),
(303, 21, 'Kabupaten Lamongan'),
(304, 21, 'Kabupaten Lumajang'),
(305, 21, 'Kabupaten Madiun'),
(306, 21, 'Kabupaten Magetan'),
(307, 21, 'Kabupaten Malang'),
(308, 21, 'Kabupaten Mojokerto'),
(309, 21, 'Kabupaten Nganjuk'),
(310, 21, 'Kabupaten Ngawi'),
(311, 21, 'Kabupaten Pacitan'),
(312, 21, 'Kabupaten Pamekasan'),
(313, 21, 'Kabupaten Pasuruan'),
(314, 21, 'Kabupaten Ponorogo'),
(315, 21, 'Kabupaten Probolinggo'),
(316, 21, 'Kabupaten Sampang'),
(317, 21, 'Kabupaten Sidoarjo'),
(318, 21, 'Kabupaten Situbondo'),
(319, 21, 'Kabupaten Sumenep'),
(320, 21, 'Kabupaten Trenggalek'),
(321, 21, 'Kabupaten Tuban'),
(322, 21, 'Kabupaten Tulungagung'),
(323, 21, 'Kota Batu'),
(324, 21, 'Kota Blitar'),
(325, 21, 'Kota Kediri'),
(326, 21, 'Kota Madiun'),
(327, 21, 'Kota Malang'),
(328, 21, 'Kota Mojokerto'),
(329, 21, 'Kota Pasuruan'),
(330, 21, 'Kota Probolinggo'),
(331, 21, 'Kota Surabaya'),
(332, 22, 'Kabupaten Badung'),
(333, 22, 'Kabupaten Bangli'),
(334, 22, 'Kabupaten Buleleng'),
(335, 22, 'Kabupaten Gianyar'),
(336, 22, 'Kabupaten Jembrana'),
(337, 22, 'Kabupaten Karangasem'),
(338, 22, 'Kabupaten Klungkung'),
(339, 22, 'Kabupaten Tabanan'),
(340, 23, 'Kabupaten Bima'),
(341, 23, 'Kabupaten Dompu'),
(342, 23, 'Kabupaten Lombok Barat'),
(343, 23, 'Kabupaten Lombok Tengah'),
(344, 23, 'Kabupaten Lombok Timur'),
(345, 23, 'Kabupaten Lombok Utara'),
(346, 23, 'Kabupaten Sumbawa'),
(347, 23, 'Kabupaten Sumbawa Barat'),
(348, 23, 'Kota Bima'),
(349, 23, 'Kota Mataram'),
(352, 22, 'Denpasar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kecamatan`
--

CREATE TABLE `kecamatan` (
  `id_kecamatan` int(11) NOT NULL,
  `id_kabupaten` int(11) NOT NULL,
  `kecamatan` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kecamatan`
--

INSERT INTO `kecamatan` (`id_kecamatan`, `id_kabupaten`, `kecamatan`) VALUES
(1, 9, 'Ciputat'),
(2, 9, 'Ciputat Timur'),
(3, 9, 'Pamulang'),
(4, 9, 'Pondok Aren'),
(6, 9, 'Serpong Utara'),
(7, 9, 'Setu'),
(10, 1, 'Denpasar');

-- --------------------------------------------------------

--
-- Struktur dari tabel `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `ip_address` varchar(128) NOT NULL,
  `user_agent` varchar(128) NOT NULL,
  `login_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `logs`
--

INSERT INTO `logs` (`id`, `id_user`, `ip_address`, `user_agent`, `login_time`) VALUES
(1, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-26 17:59:34'),
(2, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-26 18:06:24'),
(3, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-27 13:39:32'),
(4, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-27 13:41:02'),
(5, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-27 13:58:17'),
(6, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-27 13:58:48'),
(7, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-27 13:59:34'),
(8, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-27 14:00:11'),
(9, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-27 14:12:24'),
(10, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-29 16:05:13'),
(11, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-29 16:08:35'),
(12, 18, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-29 17:06:32'),
(13, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-29 17:17:59'),
(14, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-29 17:20:03'),
(15, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-29 17:25:29'),
(16, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-29 17:26:32'),
(17, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 10:37:35'),
(18, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 12:57:18'),
(19, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 14:11:52'),
(20, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 14:24:54'),
(21, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 14:36:47'),
(22, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 14:43:53'),
(23, 16, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 14:44:12'),
(24, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 14:46:59'),
(25, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 14:48:39'),
(26, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-30 14:56:23'),
(27, 19, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-31 05:02:44'),
(28, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-31 05:07:01'),
(29, 14, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36', '2022-12-31 05:19:16'),
(30, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-31 14:50:38'),
(31, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2022-12-31 15:03:44'),
(32, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 05:48:49'),
(33, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 07:12:09'),
(34, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:02:01'),
(35, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:07:10'),
(36, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:09:41'),
(37, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:10:15'),
(38, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:13:01'),
(39, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:16:18'),
(40, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:17:43'),
(41, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:20:46'),
(42, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 08:22:15'),
(43, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 12:52:10'),
(44, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-01 13:11:22'),
(45, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-02 05:05:16'),
(46, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-02 05:06:40'),
(47, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-04 13:28:10'),
(48, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-04 13:31:40'),
(49, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-05 10:51:43'),
(50, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.5', '2023-01-05 10:52:45'),
(51, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.7', '2023-01-09 05:14:45'),
(52, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.7', '2023-01-09 05:47:06'),
(53, 20, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.7', '2023-01-09 13:09:47'),
(54, 1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.7', '2023-01-09 13:31:49');

-- --------------------------------------------------------

--
-- Struktur dari tabel `product`
--

CREATE TABLE `product` (
  `id_brg` int(11) NOT NULL,
  `nama_brg` varchar(255) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(4) NOT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `product`
--

INSERT INTO `product` (`id_brg`, `nama_brg`, `keterangan`, `id_kategori`, `harga`, `stok`, `gambar`) VALUES
(11, 'Jacket Erigo', 'Casual Jacket Men', 1, 350000, 52, 'tosca.jpg'),
(14, 'Nike Air Jordan 1 Low Bred Toe GS (100% Authentic)', 'Sepatu kece badai', 6, 2700000, 10, 'nike.jpg'),
(16, 'Baju Kaos Erigo', 'Baju Kekinian', 2, 50000, 100, 'arigo3.jpg'),
(17, 'Baju Kemeja Flanel Pria', 'Baju Kemeja slebew', 7, 90000, 99, 'kemeja_flanel.jpg'),
(18, 'KAOS PRIA DISTRO COTTON COMBET 30S ', 'Baju Kekinian', 2, 32000, 100, 'kaos1.jpg'),
(19, 'Kaos Distro Original Kaos Pria Kaos Distro Murah Kaos Distro Bali', 'Baju Kekinian', 2, 32000, 100, 'kaos2.jpg'),
(20, 'Kaos Oblong Murah Meriah', 'Baju Kekinian', 2, 20000, 100, 'kaos3.jpg'),
(21, 'Baju Kaos Lucu', 'Baju Kekinian', 2, 50000, 100, 'kaos4.jpg'),
(22, 'Baju Kaos Distro Original', 'Baju Kekinian', 2, 70000, 100, 'kaos5.jpg'),
(23, 'Baju Kaos Kerah Tinggi', 'Baju Kekinian', 2, 30000, 100, 'kaos6.jpg'),
(25, 'Kaos Oblong Putih Polos', 'Baju Kekinian', 2, 20000, 100, 'kaos7.jpg'),
(26, 'Baju Kaos Pria Lengan Pendek', 'Baju Kekinian', 2, 45000, 100, 'kaos8.jpg'),
(27, 'Kaos Anime One Piece', 'Baju Kekinian', 2, 25000, 100, 'kaos9.jpg'),
(29, 'Kemeja Pria Polos Tangan Pendek', 'Baju Kemeja slebew', 7, 50000, 100, 'kemeja3.jpg'),
(30, 'Baju Kemeja Pantai Hawai', 'Baju Kemeja slebew', 7, 135000, 100, 'kemeja4.jpg'),
(32, 'Baju Kemeja BASIC Tangan Panjang', 'Baju Kemeja slebew', 7, 120000, 100, 'kemeja5.jpg'),
(33, 'Kemeja Pria Tangan Pendek', 'Baju Kemeja slebew', 7, 35000, 100, 'kemeja6.jpg'),
(34, 'Kemeja Pria BRANDED', 'Baju Kemeja slebew', 7, 900000, 20, 'kemeja7.jpg'),
(35, 'Kemeja Polos', 'Baju Kemeja slebew', 7, 80000, 100, 'kemeja8.jpg'),
(36, 'Kemeja Flanel Murah', 'Baju Kemeja slebew', 7, 65000, 100, 'kemeja9.jpg'),
(37, 'Kemeja Polos CREAM', 'Baju Kemeja slebew', 7, 50000, 100, 'kemeja10.jpg'),
(38, 'Kemeja Bermotif KEREN PARAH', 'Baju Kemeja slebew', 7, 90000, 100, 'kemeja11.jpg'),
(39, 'LIVEHAF - Trucker Canvas Jacket Dark Gray', 'jaket uhuyyy', 1, 200000, 100, 'jaket2.jpg'),
(40, 'JAKET CAMO BGSR /JAKET KEREN PRIA ELEGANTS /JAKET CAMO', 'jaket uhuyyy', 1, 120000, 100, 'jaket3.jpg'),
(41, 'jaket kulit pria keren terbaru', 'jaket uhuyyy', 1, 150000, 100, 'jaket4.jpg'),
(42, 'ERIGO HUNT JAKET PRIA MAT TASLAN MODIS KEREN', 'jaket uhuyyy', 1, 300000, 100, 'jaket5.jpg'),
(43, 'Jaket Tactical TAD 4.0 Original Impor YKK Zipper ARMY LORENG KEREN', 'jaket uhuyyy', 1, 800000, 100, 'jaket6.jpg'),
(44, 'Jaket Edmund Keren Bahan Drill Premmium Tebal Branded Original Terbaru', 'jaket uhuyyy', 1, 180000, 100, 'jaket7.jpg'),
(45, 'Jaket Pria Hoodie Cowok Motif Keren Outdor Kuliah Trendy KFK BISON', 'jaket uhuyyy', 1, 55000, 100, 'jaket8.jpg'),
(46, 'Jaket Gojek S86 Terbaru Edisi Touring Keren Abiss', 'jaket uhuyyy', 1, 150000, 100, 'jaket9.jpg'),
(47, 'Sepatu Sneakers Pria Nike Killshot Jcrew White Navy Gum Original - 44', 'Sepatu kece badai', 6, 500000, 100, 'sepatu2.jpg'),
(48, 'Sepatu Sneakers Pria Dane And Dine 987', 'Sepatu kece badai', 6, 150000, 100, 'sepatu3.jpg'),
(49, 'Sepatu Sneakers Pria Wanita Nk Aj 1 Low Smoke Grey', 'Sepatu kece badai', 6, 250000, 100, 'sepatu4.jpg'),
(50, 'Aerostreet 36-45 Massive Low Hitam - Sepatu Sneakers Casual 21AA30', 'Sepatu kece badai', 6, 140000, 100, 'sepatu5.jpg'),
(51, 'Sepatu Sneakers Pria Jimmy Official Senji putih polos promo murah', 'Sepatu kece badai', 6, 55000, 100, 'sepatu6.jpg'),
(52, 'Techdoo Sepatu Sneakers Pria Olahraga Sepatu Fashion Mesh Import MR126', 'Sepatu kece badai', 6, 100000, 100, 'sepatu7.jpg'),
(53, 'SEPATU SNEAKER FASHION STYLE PRIA NEW BRANDED GUCCAI NY QLTY', 'Sepatu kece badai', 6, 2500000, 100, 'sepatu8.jpg'),
(54, 'sepatu converse all star/sepatu sneakers pria dan wanita', 'Sepatu kece badai', 6, 50000, 100, 'sepatu9.jpg'),
(55, 'Sepatu Sneakers Running Pria Dane and Dine 992 NB', 'Sepatu kece badai', 6, 180000, 99, 'sepatu10.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `provinsi`
--

CREATE TABLE `provinsi` (
  `id_provinsi` int(11) NOT NULL,
  `provinsi` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `provinsi`
--

INSERT INTO `provinsi` (`id_provinsi`, `provinsi`) VALUES
(1, 'Nanggroe Aceh Darussalam'),
(2, 'Sumatera Utara'),
(3, 'Sumatera Selatan'),
(4, 'Sumatera Barat'),
(5, 'Bengkulu'),
(6, 'Riau'),
(7, 'Kepulauan Riau'),
(8, 'Jambi'),
(9, 'Lampung'),
(10, 'Bangka Belitung'),
(11, 'Kalimantan Timur'),
(12, 'Kalimantan Barat'),
(13, 'Kalimantan Tengah'),
(14, 'Kalimantan Selatan'),
(15, 'Kalimantan Utara'),
(16, 'DKI Jakarta'),
(17, 'Banten'),
(18, 'Jawa Barat'),
(19, 'Jawa Tengah'),
(20, 'DI Yogyakarta'),
(21, 'Jawa Timur'),
(22, 'Bali'),
(23, 'Nusa Tenggara Barat'),
(24, 'Nusa Tenggara Timur'),
(25, 'Sulawesi Utara'),
(26, 'Sulawesi Barat'),
(27, 'Sulawesi Tengah'),
(28, 'Gorontalo'),
(29, 'Sulawesi Tenggara'),
(30, 'Sulawesi Selatan'),
(31, 'Maluku Utara'),
(32, 'Maluku'),
(33, 'Papua Barat'),
(34, 'Papua'),
(35, 'Papua Selatan'),
(36, 'Papua Tengah'),
(37, 'Papua Pegunungan'),
(41, 'Bali');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `order_id` varchar(30) NOT NULL,
  `id_user` varchar(5) NOT NULL,
  `name` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `id_provinsi` int(11) NOT NULL,
  `id_kabupaten` int(11) NOT NULL,
  `id_kecamatan` int(11) DEFAULT NULL,
  `kode_pos` varchar(100) NOT NULL,
  `information` text NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `transaction_time` datetime DEFAULT NULL,
  `payment_limit` datetime DEFAULT NULL,
  `status` varchar(2) NOT NULL,
  `gambar` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `transaction`
--

INSERT INTO `transaction` (`id`, `order_id`, `id_user`, `name`, `alamat`, `id_provinsi`, `id_kabupaten`, `id_kecamatan`, `kode_pos`, `information`, `payment_method`, `transaction_time`, `payment_limit`, `status`, `gambar`) VALUES
(8, '694803', '19', 'test', 'aksjakjskaj', 17, 9, 1, '1234', '', 'Direct Bank Transfer', '2022-12-31 11:05:06', '2023-01-01 11:05:06', '1', 'erigo1.jpg'),
(9, '885154', '20', 'jun', 'bkajfjkahhfah', 14, 210, NULL, 'mnxz', '', 'Direct Bank Transfer', '2022-12-31 20:53:02', '2023-01-01 20:53:02', '0', NULL),
(10, '216840', '20', 'jun', 'fdkfjksd', 22, 1, 10, '8988', 'sesuatu disini', 'Direct Bank Transfer', '2023-01-01 14:19:44', '2023-01-02 14:19:44', '1', 'arigo31.jpg'),
(11, '1029484', '20', 'jun', 'jl. tukad badung no.135', 22, 1, 10, '8088', 'jhgjhghjg', 'Direct Bank Transfer', '2023-01-09 11:31:39', '2023-01-10 11:31:39', '0', '21.PNG');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama_pengguna` varchar(255) NOT NULL,
  `email` varchar(128) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL,
  `avatar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `nama_pengguna`, `email`, `no_hp`, `username`, `password`, `level`, `avatar`) VALUES
(1, 'Juniarta', 'admin.NOOKX@gmail.com', '', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', 'user.png'),
(19, 'test', 'test@gmail.com', '0171671161', 'test', '202cb962ac59075b964b07152d234b70', '2', 'user.png'),
(20, 'jun', 'juniartawayan94@gmail.com', '12345678912', 'juniarta', 'e10adc3949ba59abbe56e057f20f883e', '2', 'user.png');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id_account`);

--
-- Indeks untuk tabel `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `kabupaten`
--
ALTER TABLE `kabupaten`
  ADD PRIMARY KEY (`id_kabupaten`);

--
-- Indeks untuk tabel `kecamatan`
--
ALTER TABLE `kecamatan`
  ADD PRIMARY KEY (`id_kecamatan`);

--
-- Indeks untuk tabel `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id_brg`);

--
-- Indeks untuk tabel `provinsi`
--
ALTER TABLE `provinsi`
  ADD PRIMARY KEY (`id_provinsi`);

--
-- Indeks untuk tabel `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `account`
--
ALTER TABLE `account`
  MODIFY `id_account` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `category`
--
ALTER TABLE `category`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `kabupaten`
--
ALTER TABLE `kabupaten`
  MODIFY `id_kabupaten` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=353;

--
-- AUTO_INCREMENT untuk tabel `kecamatan`
--
ALTER TABLE `kecamatan`
  MODIFY `id_kecamatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT untuk tabel `product`
--
ALTER TABLE `product`
  MODIFY `id_brg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `provinsi`
--
ALTER TABLE `provinsi`
  MODIFY `id_provinsi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT untuk tabel `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
